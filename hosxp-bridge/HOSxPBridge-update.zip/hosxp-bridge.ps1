﻿# HOSxP Bridge — ส่งข้อมูลผู้ป่วยที่เปิดอยู่ใน HOSxP XE ให้หน้าต่างลอยใน clinic.html
#   หน้าจ่ายยา       → หน้าต่างลอยยาคงเหลือ (HN, วันนัด, ตารางยา)
#   หน้า Patient EMR → หน้าต่างลอยบันทึกคลินิก (HN, ชื่อ) ที่เภสัชเปิดตอนลงคลินิก
#
# อ่านจากหน้าจอ HOSxP (Windows UI Automation + จับภาพ) ไม่กด/แก้อะไรใน HOSxP
# ถ้ามี db.json อยู่โฟลเดอร์เดียวกัน (host/port/user/password/database ของ MySQL HOSxP แบบ SELECT อย่างเดียว)
# จะอ่านวันนัด/ใบสั่งยา/ยาของ visit ก่อนๆ จากฐานข้อมูลแทน OCR — ตัวต่อ MySQL อยู่ใน hxdb.cs (ไม่มีคำสั่งเขียน มีแค่ SELECT)
# เปิดให้เฉพาะเครื่องนี้ (127.0.0.1) และรับเฉพาะหน้าเว็บของเรา (ALLOWED_ORIGINS):
#   /current  — JSON { ok, hn, name, active, apptDays, gridVer, gridCut, covered, emrHn, emrName, ts }
#               emrHn/emrName = คนไข้ใน Patient EMR ที่อยู่บนจอ (มีหลายหน้า EMR เลือกหน้าที่อยู่บนสุด)
#               ถ้าไม่มีหน้า EMR ไหนเห็นบนจอ คงคนล่าสุดไว้ ไม่มีหน้า EMR เปิดเลย = ค่าว่าง
#               active = หน้าบันทึกจ่ายยาอยู่บนจอจริง (ช่อง HN และตารางยาไม่ถูกหน้าอื่น/dialog ของ HOSxP ทับ)
#               ถ้าไม่ active จะไม่อ่านวันนัด/ตารางยา และหน้าเว็บจะไม่คำนวณ
#   /emrgrid.png — ภาพตารางยาของ visit ที่เลือกใน Patient EMR (emrGridVer/emrGridHash เปลี่ยนเมื่อภาพหรือ visit เปลี่ยน)
#                 emrVisit = "วันที่มา|เวลา|ห้องตรวจ" ของ visit นั้น
#   /grid.png — ภาพตารางใบสั่งยาล่าสุด หน้าเว็บเอาไป OCR ภาษาไทยเองด้วย Tesseract (Windows OCR ไม่มีภาษาไทย)
#   /db/order?hn=   — ใบสั่งยาของ visit วันนี้ (visit ล่าสุดของวันที่มียา) + นัดที่ยังไม่ถึง (ไม่นับยกเลิก/มาแล้ว)
#   /db/visits?hn=  — ยาของ visit ก่อนวันนี้ 6 visit ล่าสุดที่มียา (ใหม่ → เก่า)
#   /db/patient?hn= — คำนำหน้า ชื่อ สกุล วันเกิด เพศ
#   /db/denom       — ตัวหาร ME รายเดือน 24 เดือนล่าสุด: opd = จำนวน visit (ovst), ipd = วันนอน (an_stat.admdate ตามเดือนที่จำหน่าย)
#   /db/me?from=YYYY-MM-DD  — รายงาน Medication error (Pharmacy > Medication error = med_error) OPD/IPD พร้อมชื่อยา/แพทย์/ผู้บันทึก
#   /db/nightmeds?date=YYYY-MM-DD[&from=19:30&to=08:00] — ยาที่สั่งช่วงเวรบ่าย-ดึก (date-1 from → date to) ทั้ง OPD/ER และ AN
#                     พร้อมแผนก เวลา admit วิธีใช้ อายุ น้ำหนัก eGFR ตั้งครรภ์ ประวัติแพ้ยา ยาเดิม 180 วัน ตารางยาตีกัน
#                     — หน้า night-meds.html คัดยาที่ต้องคืนรถยา + ตรวจขนาดยา/ยาตีกัน/แพ้ยา
#   /db/errx?hn=&date=YYYY-MM-DD — ใบสั่งยาของ HN นี้วันที่ date-1 และ date (แยกตาม VN/AN + เวลาสั่งแรก) พร้อมชื่อ อายุ
#                     — ฟอร์มลง ME ER ใน ME_Dashboard.html ใส่แค่ HN แล้วเติมชื่อ อายุ วันที่/เวลาสั่งยาให้
#   /db/adr?from=YYYY-MM-DD — รายงาน ADR (Pharmacy > Adverse drug reactions = patient_adr) พร้อมรายละเอียดทุกช่องและรายการยา
#   /db/dmroster    — คนไข้ที่มีนัดคลินิก NCDs remission (clinic 032)
#   /db/dmvisits?hn= — วันที่เข้าคลินิก NCDs remission แต่ละครั้ง พร้อมสัญญาณชีพ lab (ล่าสุดภายใน 60 วันก่อนวันนั้น) และยาที่ได้
#   /db/dmscreen    — คัดกรองคนไข้คลินิกเบาหวาน (023 นัด LAB, 001 DM) ใน 1 ปี: HbA1c 2 ปี + การจ่ายยาลดน้ำตาล 2 ปี + ปีที่เริ่มเป็น DM
#   /db/rxqueue     — visit วันนี้/เมื่อคืนที่มียา (ล่าสุด 40 visit) + ใครล็อก VN อยู่ (vn_lock) — หน้า rx-sticker.html
#   /db/rxsticker?hn= — ข้อมูลสติกเกอร์ยาแต่ละรายการของ visit วันนี้/เมื่อวาน ตามแบบ StickerDetailReport.rtm ของ HOSxP
#                     (ชื่อยา name_print, วิธีใช้ 3 บรรทัด, คำเตือน drughint, therapeutic, ชื่อสามัญไทย, เก็บพ้นแสง/ยาปฏิชีวนะ)
#   /db/mrmeds?hn=&an= — ยาที่ได้รับจาก รพ. 1 ปีก่อน admit (OPD + ยากลับบ้าน) — สติกเกอร์ยาเดิมแปะใบ MR
#   /db/mrvisits?hn=&an= — ทุก visit OPD ที่มียา + ยากลับบ้านทุกครั้ง ใน 1 ปีก่อน admit พร้อมรายการยา — เภสัชเลือกดึงยาเดิมจาก visit อื่นเพิ่ม
#   /db/mrdict      — รายการยาทั้งหมด (drugitems) + วิธีใช้ที่เปิดใช้ (drugusage.status='Y') พร้อมรหัสย่อ — คีย์ยาเดิมจาก รพ.อื่น ในใบ MR
#   /db/ipdlist     — ผู้ป่วยในที่ยังไม่จำหน่าย (ward, เตียง, AN, HN, ชื่อ) — หัวสติกเกอร์ผู้ป่วยในแปะรถยา (แบบ CUSTOM- stickerผู้ป่วยใน) + อายุ น้ำหนัก แพ้ยา โรคประจำตัว สำหรับหัวสติกเกอร์ MR
#   /db/hme         — ใบสั่งยากลับบ้าน (ipt_order_no.order_type='HMe') วันนี้/เมื่อวาน พร้อมรายการยาและวิธีใช้ — พิมพ์สรุปยากลับบ้านอัตโนมัติ
#   /db/smartrx?hn= — Smart Pharmacy: อายุ เพศ สัญญาณชีพ lab แพ้ยา วินิจฉัย ตารางยาตีกัน — หน้าต่างลอยจ่ายยาของเภสัชกร
#   /db/meds?hn=    — ยาเดิมสำหรับบันทึกยาคงเหลือ: visit ล่าสุด (ก่อนวันนี้) ที่มียา ของแต่ละคลินิกนัด DM/HT/COPD
#                     + ยากลับบ้าน (HMe) ของการนอน รพ. ครั้งล่าสุด — หน้าเว็บเลือก/รวมเอง
#   ทุกตัวคืน { ok:false, error } ถ้าไม่มี db.json หรือต่อฐานข้อมูลไม่ได้ — หน้าเว็บกลับไปใช้ OCR เอง
#   /current มี db (ต่อฐานข้อมูลได้) / dbErr และถ้า DB ใช้ได้ apptDays มาจากตาราง oapp ไม่ใช่ OCR
#   /current มี hotkey/hotkeySeq/hotkeyTs = ปุ่มลัดที่กดล่าสุด ('rph' Ctrl+Alt+P, 'tech' Ctrl+Alt+J)
#
# ปุ่มลัดทั้งเครื่อง (กดได้ขณะอยู่ใน HOSxP): Ctrl+Alt+P = หน้าต่างลอยจ่ายยาเภสัชกร, Ctrl+Alt+J = ยาคงเหลือ จพ.
#   เปิดหน้าต่างลอยอยู่แล้ว → ดึงขึ้นมาข้างหน้า, ไม่งั้นสลับไปแท็บ clinic.html (หรือเปิดแท็บใหม่ถ้าไม่มี)
#   Chrome ให้เปิดหน้าต่างลอยได้เฉพาะตอนผู้ใช้กดปุ่มบนหน้านั้น หน้าเว็บจึงขึ้น "กด Enter เพื่อเปิด" ให้กดอีกครั้ง
#
# ตำแหน่งข้อมูลในหน้าจ่ายยา (THOSxPDiepensingDispenseEntryFrame) ของ HOSxP XE 4:
#   HN / ชื่อ     — TcxDBTextEdit ที่อยู่ทางขวาของป้าย "HN" / "ชื่อ"
#   วันนัด        — THTMListBox ในกล่อง "ข้อมูลการนัดหมาย" แสดงเป็น "1.[119 วัน] 22 มกราคม 2570 ..."
#                   วาดข้อความเอง อ่านผ่าน API ไม่ได้ จึงจับภาพแล้ว OCR (อังกฤษพอ) เอาตัวเลขในวงเล็บ [..]
#   ใบสั่งยา       — TcxGridSite ใน THOSxPMedicationOrderFrame (DevExpress grid อ่านผ่าน API ไม่ได้เช่นกัน)
# Patient EMR (TPtEMRForm) — ส่วนหัวไม่มีป้ายกำกับ อ่านตามตำแหน่ง: HN = ช่อง TcxTextEdit ที่เป็นตัวเลขล้วน
#   แถวบนสุด (7 หลัก, แถวล่างลงไปเป็นเลขบัตรประชาชน/โทรศัพท์) ชื่อ = ช่องถัดไปทางขวาในแถวเดียวกัน
# HOSxP ไม่ตอบ PrintWindow จึงต้องจับภาพจากจอจริง — ถ้ามีหน้าต่างอื่นบังอยู่ (รวมถึงหน้าอื่นของ HOSxP
# เช่น "เปรียบเทียบประวัติ") จะไม่จับส่วนที่ถูกบัง และคงผลที่อ่านได้ล่าสุดของคนไข้คนนี้ไว้

#   /version[?check=1] — เวอร์ชันของ bridge เครื่องนี้ (check=1 = เทียบกับไฟล์ล่าสุดบนเว็บด้วย)
#   /update  — ดาวน์โหลดไฟล์ bridge ล่าสุดจากเว็บ (UPDATE_BASE) แทนของเดิม แล้วเปิดตัวใหม่เอง — ปุ่ม "อัปเดต Bridge" ในหน้าเว็บ
#
# Mac (pwsh 7, HOSxP รันใน Wine): อ่านหน้าจอไม่ได้ — HN มาจากฐานข้อมูลแทน (คนไข้ที่เครื่องนี้เปิด Patient EMR ล่าสุด, MacUpdateState)
#   /current มี pc = ชื่อเครื่องใน HOSxP ที่ใช้หา — ติดตั้งด้วย mac/Install HOSxP Bridge.command

$PORT = if ($env:HXB_PORT) { [int]$env:HXB_PORT } else { 8765 }
$ALLOWED_ORIGINS = @('https://oatsudster.github.io', 'https://tph-pharmacy.pages.dev', 'null')   # 'null' = เปิดไฟล์ html จากเครื่องตรงๆ · tph-pharmacy.pages.dev = Cloudflare Pages (ลิงก์ที่ 2 ของเว็บเดียวกัน)
$UPDATE_ORIGINS = @('https://oatsudster.github.io', 'https://tph-pharmacy.pages.dev')   # สั่ง /update ได้เฉพาะหน้าเว็บของเราจริง (ไม่รับ 'null')
$UPDATE_BASE = if ($env:HXB_UPDATE_BASE) { $env:HXB_UPDATE_BASE } else { 'https://oatsudster.github.io/pharmacy-tph/hosxp-bridge/' }   # HXB_UPDATE_BASE ใช้ทดสอบ
$OS = if ($PSVersionTable.PSEdition -eq 'Desktop' -or $IsWindows) { 'win' } else { 'mac' }
# อ่านหน้าจอ HOSxP (UI Automation + OCR ของ Windows) ได้เฉพาะ Windows PowerShell 5.1 — HXB_NOSCREEN=1 ใช้ทดสอบโหมด Mac บน Windows
$SCREEN = $PSVersionTable.PSEdition -eq 'Desktop' -and -not $env:HXB_NOSCREEN
# pwsh 7 ใช้ปฏิทินตามภาษาเครื่อง (th-TH = พ.ศ.) ทั้งตอนแปลงวันที่เป็นข้อความและตอน ParseExact — ล็อกเป็น invariant (ค.ศ.)
if ($PSVersionTable.PSEdition -ne 'Desktop') {
  [System.Globalization.CultureInfo]::DefaultThreadCurrentCulture = [System.Globalization.CultureInfo]::InvariantCulture
  [System.Threading.Thread]::CurrentThread.CurrentCulture = [System.Globalization.CultureInfo]::InvariantCulture
}

if ($SCREEN) {
Add-Type -AssemblyName UIAutomationClient, UIAutomationTypes, System.Drawing, System.Runtime.WindowsRuntime
Add-Type @"
using System;
using System.Runtime.InteropServices;
public static class HxWin {
  [StructLayout(LayoutKind.Sequential)] public struct POINT { public int X, Y; }
  [DllImport("user32.dll")] public static extern IntPtr WindowFromPoint(POINT p);
  [DllImport("user32.dll")] public static extern bool IsChild(IntPtr parent, IntPtr h);
  [DllImport("user32.dll")] public static extern bool SetProcessDPIAware();
  // จุดบนจอนี้คือตัว control นั้นจริงหรือไม่ — ถ้ามีหน้าต่างอื่นบัง แม้เป็นของ HOSxP เอง
  // (เช่น "เปรียบเทียบประวัติ") ก็ถือว่าถูกบัง จะได้ไม่เอาภาพหน้านั้นไปอ่าน
  public static bool IsShowing(int x, int y, IntPtr target) {
    POINT p; p.X = x; p.Y = y;
    IntPtr h = WindowFromPoint(p);
    return h == target || IsChild(target, h);
  }
  // ปุ่มลัดทั้งเครื่อง (Ctrl+Alt+P / Ctrl+Alt+J) — WM_HOTKEY เข้าคิวของ thread ที่ลงทะเบียน ดึงออกในลูปหลัก
  [StructLayout(LayoutKind.Sequential)] public struct MSG { public IntPtr hwnd; public uint message; public IntPtr wParam; public IntPtr lParam; public uint time; public POINT pt; }
  [DllImport("user32.dll")] public static extern bool RegisterHotKey(IntPtr h, int id, uint mods, uint vk);
  [DllImport("user32.dll")] static extern bool PeekMessage(out MSG m, IntPtr h, uint min, uint max, uint remove);
  [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr h);
  [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr h, int cmd);
  [DllImport("user32.dll")] static extern bool IsIconic(IntPtr h);
  public static int PollHotkey() { MSG m; return PeekMessage(out m, IntPtr.Zero, 0x0312, 0x0312, 1) ? (int)m.wParam : 0; }
  [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr h);
  [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
  [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr h, IntPtr pid);
  [DllImport("user32.dll")] static extern bool AttachThreadInput(uint a, uint b, bool attach);
  [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
  // Windows ไม่ให้โปรแกรมเบื้องหลังดึงหน้าต่างขึ้นมาข้างหน้าเฉยๆ — ผูก input กับหน้าต่างที่อยู่ข้างหน้าตอนนี้ (HOSxP) ชั่วคราวก่อน
  public static void Focus(IntPtr h) {
    if (IsIconic(h)) ShowWindow(h, 9);
    uint me = GetCurrentThreadId(), fg = GetWindowThreadProcessId(GetForegroundWindow(), IntPtr.Zero);
    bool att = fg != 0 && fg != me && AttachThreadInput(me, fg, true);
    BringWindowToTop(h); SetForegroundWindow(h);
    if (att) AttachThreadInput(me, fg, false);
  }
}
"@
# ใช้พิกัดจอจริง เครื่องที่ตั้งขนาดหน้าจอ 125%/150% ตำแหน่งจาก UI Automation จะได้ตรงกับภาพที่จับ
[void][HxWin]::SetProcessDPIAware()
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Foundation, ContentType = WindowsRuntime]

$AE = [System.Windows.Automation.AutomationElement]
$TS = [System.Windows.Automation.TreeScope]
function ClassCond($cls) { New-Object System.Windows.Automation.PropertyCondition($AE::ClassNameProperty, $cls) }

$asTask = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
  $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
function Await($op, [Type]$t) { $task = $asTask.MakeGenericMethod($t).Invoke($null, @($op)); $task.Wait(-1) | Out-Null; $task.Result }
# วันนัดต้องการแค่ตัวเลขในวงเล็บ ใช้ OCR ภาษาอังกฤษของ Windows ได้
$ocr = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
if (-not $ocr) { $ocr = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new('en-US')) }
}
$md5 = [System.Security.Cryptography.MD5]::Create()

$state = [ordered]@{ ok = $false; hn = ''; name = ''; active = $false; apptDays = $null; db = $false; dbErr = ''; ver = ''; os = $OS; gridVer = 0; gridHash = ''; gridCut = $false; covered = $false; emrHn = ''; emrName = ''; emrGridVer = 0; emrGridHash = ''; emrVisit = ''; hotkey = ''; hotkeySeq = 0; hotkeyTs = 0; ts = 0 }
$cache = @{ hnEdit = $null; nameEdit = $null; apptList = $null; grid = $null; emr = @(); layout2 = $false }
$nextEmrScan = [DateTime]::MinValue; $nextFind = [DateTime]::MinValue
$nextCard = [DateTime]::MinValue
$apptByHn = @{}   # HN → จำนวนวันถึงนัดที่อ่านได้ล่าสุด (ล้างเมื่อปิด bridge)
$gridPng = $null; $gridHash = ''
$emrGridPng = $null; $emrGridRaw = ''; $nextEmrGrid = [DateTime]::MinValue
$lastHn = ''; $nextAppt = [DateTime]::MinValue; $nextGrid = [DateTime]::MinValue

# ── ฐานข้อมูล HOSxP (อ่านอย่างเดียว) ─────────────────────────
$db = $null
$dbFile = Join-Path $PSScriptRoot 'db.json'
if (Test-Path $dbFile) {
  try {
    Add-Type -Path (Join-Path $PSScriptRoot 'hxdb.cs')
    $cfg = Get-Content $dbFile -Raw -Encoding UTF8 | ConvertFrom-Json
    $db = New-Object HxDb $cfg.host, ([int]$(if ($cfg.port) { $cfg.port } else { 3306 })), $cfg.user, $cfg.password, $(if ($cfg.database) { $cfg.database } else { 'hos' })
  } catch { $state.dbErr = "ตั้งค่าฐานข้อมูลไม่ได้: $($_.Exception.Message)" }
} else { $state.dbErr = 'ไม่มี db.json' }
$dbRetryAt = [DateTime]::MinValue
$apptDbAt = @{}   # HN → เวลาที่อ่านวันนัดจาก DB ล่าสุด

# รัน SELECT — ต่อไม่ได้ให้เว้น 30 วินาทีก่อนลองใหม่ (bridge ทำงานวนรอบเดียว จะได้ไม่ค้างรอ DB ทุกวินาที)
function DbQuery($sql) {
  if (-not $db) { throw $state.dbErr }
  if (-not $db.Connected -and (Get-Date) -lt $script:dbRetryAt) { throw $state.dbErr }
  try { $r = $db.Query($sql); $state.db = $true; $state.dbErr = ''; return , $r }
  catch {
    $msg = if ($_.Exception.InnerException) { $_.Exception.InnerException.Message } else { $_.Exception.Message }
    # คำสั่งช้าเกินเวลารอ (HxDb ขึ้นต้น "HOSxP ตอบช้า") ไม่ใช่ DB ล่ม — ไม่พักการต่อ 30 วิ ให้หน้าอื่นใช้ต่อได้
    if (-not $db.Connected -and -not $msg.StartsWith('HOSxP ตอบช้า')) { $state.db = $false; $script:dbRetryAt = (Get-Date).AddSeconds(30) }
    $state.dbErr = $msg; throw $msg
  }
}

# วิธีใช้: 3 บรรทัดต่อกันเหมือนบนฉลากยา — วิธีใช้ที่แก้ใน HOSxP ภายหลัง (opi_dispense.usage_lock='Y' → usage_line1-3)
# ก่อน แล้วข้อความวิธีใช้พิเศษ (sp_use) แล้วรหัสวิธีใช้ปกติ — ลำดับเดียวกับ StickerDetailReport
# (2026-10-22: HN 4802454 Lasix รหัส .51pt แก้เป็น "...เช้า เวลาบวม" แต่เดิมดึงข้อความตามรหัส)
$DRUG_COLS = "d.icode, d.name, d.strength, d.units, d.dosageform, r.qty, r.item_no, " +
  "TRIM(IF(od.usage_lock='Y', CONCAT_WS(' ', od.usage_line1, od.usage_line2, od.usage_line3), " +
  "IF(r.sp_use IS NOT NULL AND r.sp_use<>'', CONCAT_WS(' ', s.name1, s.name2, s.name3), CONCAT_WS(' ', u.name1, u.name2, u.name3)))) AS usage_text"
$DRUG_JOIN = "FROM opitemrece r JOIN drugitems d ON d.icode=r.icode " +
  "LEFT JOIN drugusage u ON u.drugusage=r.drugusage LEFT JOIN sp_use s ON s.sp_use=r.sp_use " +
  "LEFT JOIN opi_dispense od ON od.hos_guid=r.hos_guid"

# $hn ผ่าน [HxDb]::Digits มาแล้วทุกครั้ง (ตัวเลขล้วน) จึงใส่ใน SQL ได้ตรงๆ
function DbAppts($hn) {
  $rows = DbQuery ("SELECT a.nextdate, DATEDIFF(a.nextdate, CURDATE()) AS days, k.department AS clinic, a.app_cause " +
    "FROM oapp a LEFT JOIN kskdepartment k ON k.depcode=a.depcode " +
    "WHERE a.hn='$hn' AND a.nextdate>CURDATE() AND (a.oapp_status_id IS NULL OR a.oapp_status_id=1) ORDER BY a.nextdate")
  , @($rows | ForEach-Object { [ordered]@{ date = $_['nextdate']; days = [int]$_['days']; clinic = $_['clinic']; cause = $_['app_cause'] } })
}

function DrugRow($r) {
  [ordered]@{ icode = $r['icode']; name = $r['name']; strength = $r['strength']; units = $r['units']; form = $r['dosageform']; qty = $r['qty']; usage = $r['usage_text'] }
}

function DbOrder($hn) {
  $rows = DbQuery ("SELECT r.vn, o.vsttime, $DRUG_COLS $DRUG_JOIN JOIN ovst o ON o.vn=r.vn " +
    "WHERE r.hn='$hn' AND r.vstdate=CURDATE() AND (r.an IS NULL OR r.an='') ORDER BY r.vn DESC, r.item_no")
  $vn = if ($rows.Count) { $rows[0]['vn'] } else { '' }
  $appts = DbAppts $hn
  $max = if ($appts.Count) { ($appts | ForEach-Object { $_.days } | Measure-Object -Maximum).Maximum } else { $null }
  [ordered]@{ ok = $true; hn = $hn; vn = $vn; time = $(if ($rows.Count) { $rows[0]['vsttime'] } else { '' })
    drugs = @($rows | Where-Object { $_['vn'] -eq $vn } | ForEach-Object { DrugRow $_ }); appts = $appts; apptDays = $max }
}

function DbVisits($hn) {
  $rows = DbQuery ("SELECT r.vn, r.vstdate, o.vsttime, k.department, $DRUG_COLS $DRUG_JOIN JOIN ovst o ON o.vn=r.vn " +
    "LEFT JOIN kskdepartment k ON k.depcode=o.main_dep " +
    "WHERE r.hn='$hn' AND r.vstdate<CURDATE() AND r.vstdate>=CURDATE()-INTERVAL 2 YEAR AND (r.an IS NULL OR r.an='') " +
    "ORDER BY r.vstdate DESC, r.vn DESC, r.item_no LIMIT 300")
  $visits = New-Object System.Collections.ArrayList; $cur = $null
  foreach ($r in $rows) {
    if (-not $cur -or $cur.vn -ne $r['vn']) {
      if ($visits.Count -ge 6) { break }
      $cur = [ordered]@{ vn = $r['vn']; date = $r['vstdate']; time = $r['vsttime']; dep = $r['department']; drugs = New-Object System.Collections.ArrayList }
      [void]$visits.Add($cur)
    }
    [void]$cur.drugs.Add((DrugRow $r))
  }
  # ยากลับบ้าน (HMe) ของการนอน รพ. ที่จำหน่ายแล้ว นับเป็น visit หนึ่ง ณ วันจำหน่าย — ไม่งั้นคนที่เพิ่งออกจาก รพ.
  # จะถูกเทียบกับ visit OPD ก่อน admit (vn = "AN" + an ไม่ซ้ำกับ vn จริง)
  $ipts = DbQuery "SELECT an, dchdate, dchtime FROM ipt WHERE hn='$hn' AND dchdate IS NOT NULL AND dchdate<CURDATE() AND dchdate>=CURDATE()-INTERVAL 2 YEAR ORDER BY dchdate DESC, dchtime DESC LIMIT 6"
  foreach ($i in $ipts) {
    $an = [HxDb]::Digits($i['an'])
    $hme = DbQuery ("SELECT $DRUG_COLS $DRUG_JOIN JOIN ipt_order_no n ON n.an=r.an AND n.order_no=r.order_no " +
      "WHERE r.an='$an' AND n.order_type='HMe' ORDER BY r.item_no")
    if (-not $hme.Count) { continue }
    [void]$visits.Add([ordered]@{ vn = "AN$an"; date = $i['dchdate']; time = $i['dchtime']; dep = 'ยากลับบ้าน (admit)'
      drugs = @($hme | ForEach-Object { DrugRow $_ }) })
  }
  $visits = @($visits | Sort-Object -Property @{ Expression = { "$($_.date) $($_.time)" }; Descending = $true } | Select-Object -First 6)
  [ordered]@{ ok = $true; hn = $hn; visits = $visits }
}

# คลินิกนัดที่ใช้หายาเดิม: คลินิคเบาหวานนัดLAB, โรคเบาหวาน(DM), คลีนิคความดันนัดLAB, โรคความดัน(HT), โรคถุงลมโปงพอง(COPD)
$MED_CLINICS = "'023','001','024','002','013'"
function DbMeds($hn) {
  # visit ที่มาตามนัดของคลินิกเหล่านี้ — ผูกกับนัดด้วย visit_vn ถ้าไม่ได้ผูก ใช้ visit ของ HN นี้ในวันนัด
  # + visit ที่ "ออกนัด" คลินิกเหล่านี้ (oapp.vn) = visit ที่จ่ายยาถึงวันนัด (2026-10-29: HN 4700684 มาช้ากว่านัด, HN 5501044
  #   ได้ยาที่ OPD ทั่วไปแล้วนัด DM — เดิมไม่ถูกดึงเพราะ visit นั้นไม่ได้มาตามนัด DM/HT/COPD)
  # o.hn='$hn' ใน WHERE: เงื่อนไข OR ใน JOIN ทำให้ MySQL ไล่ ovst ทั้งตาราง (1.2 ล้านแถว) ต่อนัดทุกรายการ — คนไข้นัดเยอะ
  #   ใช้ >20 วิ เกินเวลารอของ bridge แล้วหน้าเว็บขึ้นว่าไม่ได้ต่อ bridge (2026-11-02: AN 690001206 20.9 วิ → 0.01 วิ ผลเท่าเดิม)
  $vis = DbQuery ("SELECT a.clinic, c.name AS clinic_name, o.vn, o.vstdate, o.vsttime FROM oapp a " +
    "JOIN clinic c ON c.clinic=a.clinic " +
    "JOIN ovst o ON o.vn=a.visit_vn OR o.vn=a.vn OR ((a.visit_vn IS NULL OR a.visit_vn='') AND o.hn=a.hn AND o.vstdate=a.nextdate) " +
    "WHERE a.hn='$hn' AND o.hn='$hn' AND a.clinic IN ($MED_CLINICS) AND a.nextdate>=CURDATE()-INTERVAL 2 YEAR AND o.vstdate<CURDATE() " +
    "ORDER BY o.vstdate DESC, o.vn DESC LIMIT 40")
  $drugs = @{}
  if ($vis.Count) {
    $vns = ($vis | ForEach-Object { "'" + [HxDb]::Digits($_['vn']) + "'" } | Select-Object -Unique) -join ','
    foreach ($r in (DbQuery "SELECT r.vn, $DRUG_COLS $DRUG_JOIN WHERE r.vn IN ($vns) AND (r.an IS NULL OR r.an='') ORDER BY r.item_no")) {
      if (-not $drugs.ContainsKey($r['vn'])) { $drugs[$r['vn']] = New-Object System.Collections.ArrayList }
      [void]$drugs[$r['vn']].Add((DrugRow $r))
    }
  }
  # แต่ละคลินิกเอา visit ล่าสุดที่มียา (นัด LAB บางครั้งไม่มียา ข้ามไป visit ก่อนหน้าของคลินิกนั้น)
  $visits = New-Object System.Collections.ArrayList; $seen = @{}; $used = @{}
  foreach ($v in $vis) {
    if ($seen.ContainsKey($v['clinic']) -or -not $drugs.ContainsKey($v['vn'])) { continue }
    $seen[$v['clinic']] = $true
    # visit เดียวกันทั้งมาตามนัดคลินิกหนึ่งและออกนัดอีกคลินิก เอาครั้งเดียว
    if ($used.ContainsKey("$($v['vn'])")) { continue }
    $used["$($v['vn'])"] = $true
    [void]$visits.Add([ordered]@{ clinic = $v['clinic']; clinicName = $v['clinic_name']; vn = $v['vn']; date = $v['vstdate']; time = $v['vsttime']; drugs = $drugs[$v['vn']] })
  }
  # ยากลับบ้านของการนอน รพ. ครั้งล่าสุดที่จำหน่ายแล้ว
  $dc = $null
  $ipt = DbQuery "SELECT an, regdate, dchdate, dchtime FROM ipt WHERE hn='$hn' AND dchdate IS NOT NULL AND dchdate<=CURDATE() AND dchdate>=CURDATE()-INTERVAL 2 YEAR ORDER BY dchdate DESC, dchtime DESC LIMIT 1"
  if ($ipt.Count) {
    $an = [HxDb]::Digits($ipt[0]['an'])
    $hme = DbQuery ("SELECT $DRUG_COLS $DRUG_JOIN JOIN ipt_order_no n ON n.an=r.an AND n.order_no=r.order_no " +
      "WHERE r.an='$an' AND n.order_type='HMe' ORDER BY r.item_no")
    $dc = [ordered]@{ an = $an; regdate = $ipt[0]['regdate']; dchdate = $ipt[0]['dchdate']; dchtime = $ipt[0]['dchtime']
      drugs = @($hme | ForEach-Object { DrugRow $_ }) }
  }
  [ordered]@{ ok = $true; hn = $hn; visits = $visits; discharge = $dc }
}

# ตัวหาร ME — นับแบบเดียวกับที่กรอกมือมาตลอด (ตรวจแล้วตรงกับที่กรอกไว้ ต.ค. 68 – ก.ย. 69)
function DbDenom {
  $from = "DATE_FORMAT(CURDATE() - INTERVAL 24 MONTH, '%Y-%m-01')"
  $months = [ordered]@{}
  foreach ($r in (DbQuery "SELECT DATE_FORMAT(vstdate, '%Y-%m') AS m, COUNT(*) AS n FROM ovst WHERE vstdate>=$from GROUP BY 1")) {
    $months[$r['m']] = [ordered]@{ opd = [int]$r['n']; ipd = $null }
  }
  foreach ($r in (DbQuery "SELECT DATE_FORMAT(dchdate, '%Y-%m') AS m, SUM(admdate) AS n FROM an_stat WHERE dchdate>=$from AND dchdate<=CURDATE() GROUP BY 1")) {
    if (-not $months.Contains($r['m'])) { $months[$r['m']] = [ordered]@{ opd = $null; ipd = $null } }
    $months[$r['m']].ipd = [int]$r['n']
  }
  [ordered]@{ ok = $true; months = $months }
}

# รายงาน ADR ของห้องยา พร้อมรายละเอียดที่ต้องกดเข้าไปดูทีละคนใน HOSxP
# ชนิด Type A/B ไม่มีใน patient_adr — ใช้ของ opd_allergy (ประวัติแพ้ยา) ของคนเดียวกันที่บันทึกใกล้วันรายงานที่สุด (±60 วัน)
function DbMe($path) {
  # วันที่ = update_datetime (ตรงกับคอลัมน์ วันที่/เวลา ของรายงาน Excel ที่ส่งออกจาก HOSxP)
  $from = '2025-10-01'
  if ($path -match '[?&]from=(\d{4}-\d{2}-\d{2})') { $from = $Matches[1] }
  $rows = DbQuery ("SELECT m.med_error_id, m.hn, m.vn, m.dep_type, m.icode, DATE_FORMAT(m.update_datetime, '%Y-%m-%d') AS d, " +
    "DATE_FORMAT(m.update_datetime, '%H:%i') AS t, CONCAT(IFNULL(p.pname,''), IFNULL(p.fname,''), ' ', IFNULL(p.lname,'')) AS ptname, " +
    "dr.name AS doctor, di.name AS drug, pt.med_error_process_type_name AS stage, rt.med_error_risk_type_name AS severity, " +
    "et.med_error_type_name AS metype, m.med_error_note_text AS note, o.officer_name AS officer " +
    "FROM med_error m LEFT JOIN patient p ON p.hn=m.hn LEFT JOIN doctor dr ON dr.code=m.doctor_code " +
    "LEFT JOIN drugitems di ON di.icode=m.icode LEFT JOIN officer o ON o.officer_id=m.officer_id " +
    "LEFT JOIN med_error_process_type pt ON pt.med_error_process_type_id=m.med_error_process_type_id " +
    "LEFT JOIN med_error_risk_type rt ON rt.med_error_risk_type_id=m.med_error_risk_type_id " +
    "LEFT JOIN med_error_type et ON et.med_error_type_id=m.med_error_type_id " +
    "WHERE m.update_datetime>='$from' ORDER BY m.update_datetime, m.med_error_id LIMIT 2000")
  $items = @($rows | ForEach-Object {
    [ordered]@{ id = $_['med_error_id']; hn = $_['hn']; vn = $_['vn']; dept = $_['dep_type']; date = $_['d']; time = $_['t']
      patient = $_['ptname'].Trim(); doctor = $_['doctor']; icode = $_['icode']; drug = $_['drug']; stage = $_['stage']
      severity = $_['severity']; meType = $_['metype']; note = $_['note']; officer = $_['officer'] }
  })
  [ordered]@{ ok = $true; items = $items }
}
function DbNightMeds($path) {
  # ใช้ rxdate IN (2 วัน) ให้ใช้ index ix_rxdate ได้ (ห้าม TIMESTAMP(rxdate,rxtime) ตรงๆ — สแกนทั้งตาราง)
  if ($path -notmatch '[?&]date=(\d{4}-\d{2}-\d{2})') { throw 'ต้องระบุ date=YYYY-MM-DD' }
  $d = [datetime]::ParseExact($Matches[1], 'yyyy-MM-dd', $null)
  $from = '19:30:00'; $to = '08:00:00'
  if ($path -match '[?&]from=(\d{1,2}):(\d{2})') { $from = '{0:00}:{1}:00' -f [int]$Matches[1], $Matches[2] }
  if ($path -match '[?&]to=(\d{1,2}):(\d{2})') { $to = '{0:00}:{1}:00' -f [int]$Matches[1], $Matches[2] }
  $d0 = $d.AddDays(-1).ToString('yyyy-MM-dd'); $d1 = $d.ToString('yyyy-MM-dd')
  # วิธีใช้: ข้อความวิธีใช้พิเศษ (sp_use) ถ้ามี ไม่งั้นรหัสวิธีใช้ปกติ — ใช้ตรวจขนาดยา
  $rows = DbQuery ("SELECT o.vn, o.an, o.hn, DATE_FORMAT(o.rxdate,'%Y-%m-%d') AS rxdate, TIME_FORMAT(o.rxtime,'%H:%i') AS rxtime, " +
    "o.dep_code, k.department, o.staff, o.icode, d.name, d.strength, d.units, d.dosageform, o.qty, " +
    "TRIM(IF(o.sp_use IS NOT NULL AND o.sp_use<>'', CONCAT_WS(' ', sp.name1, sp.name2, sp.name3), CONCAT_WS(' ', u.name1, u.name2, u.name3))) AS usage_text, " +
    "u.iperday, u.iperdose, " +
    # ฉลากติดขวดน้ำเกลือ 1000 ml (แบบสติกเกอร์ยา HOSxP — StickerDetailReport.rtm เหมือน DbRxSticker)
    "IF(od.usage_lock='Y', od.usage_line1, IF(o.sp_use<>'', sp.name1, u.name1)) AS line1, " +
    "IF(od.usage_lock='Y', od.usage_line2, IF(o.sp_use<>'', sp.name2, u.name2)) AS line2, " +
    "IF(od.usage_lock='Y', od.usage_line3, IF(o.sp_use<>'', sp.name3, u.name3)) AS line3, " +
    "TRIM(IFNULL(d.name_print,'')) AS name_print, d.thai_name, d.therapeutic, h.hinttext, ov.oqueue, " +
    "TRIM(CONCAT(IFNULL(p.pname,''), IFNULL(p.fname,''), ' ', IFNULL(p.lname,''))) AS ptname, p.sex, " +
    "TIMESTAMPDIFF(MONTH, p.birthday, o.rxdate) AS age_m, s.bw, s.height, s.pregnancy, s.egfr, " +
    "DATE_FORMAT(i.regdate,'%Y-%m-%d') AS regdate, TIME_FORMAT(i.regtime,'%H:%i') AS regtime, w.name AS ward " +
    "FROM opitemrece o JOIN drugitems d ON d.icode=o.icode LEFT JOIN patient p ON p.hn=o.hn " +
    "LEFT JOIN drugusage u ON u.drugusage=o.drugusage LEFT JOIN sp_use sp ON sp.sp_use=o.sp_use " +
    "LEFT JOIN kskdepartment k ON k.depcode=o.dep_code LEFT JOIN ipt i ON i.an=o.an LEFT JOIN ward w ON w.ward=i.ward " +
    "LEFT JOIN opdscreen s ON s.vn=IF(o.vn IS NULL OR o.vn='', i.vn, o.vn) " +
    "LEFT JOIN opi_dispense od ON od.hos_guid=o.hos_guid LEFT JOIN drughint h ON h.hc=d.hintcode AND IFNULL(d.hintcode,'')<>'' " +
    "LEFT JOIN ovst ov ON ov.vn=o.vn " +
    "WHERE o.rxdate IN ('$d0','$d1') AND ((o.rxdate='$d0' AND o.rxtime>='$from') OR (o.rxdate='$d1' AND o.rxtime<'$to')) " +
    "ORDER BY o.rxdate, o.rxtime, o.hn, o.item_no LIMIT 5000")
  $items = @($rows | ForEach-Object {
    [ordered]@{ vn = $_['vn']; an = $_['an']; hn = $_['hn']; name = $_['ptname']; date = $_['rxdate']; time = $_['rxtime']
      dep = $_['dep_code']; depName = $_['department']; staff = $_['staff']; icode = $_['icode']; drug = $_['name']; strength = $_['strength']
      units = $_['units']; form = $_['dosageform']; qty = $_['qty']; usage = $_['usage_text']; iperday = $_['iperday']; iperdose = $_['iperdose']
      sex = $_['sex']; ageM = $_['age_m']; bw = $_['bw']; height = $_['height']; pregnancy = $_['pregnancy']; egfr = $_['egfr']
      regdate = $_['regdate']; regtime = $_['regtime']; ward = $_['ward']
      line1 = $_['line1']; line2 = $_['line2']; line3 = $_['line3']; namePrint = $_['name_print']; thaiName = $_['thai_name']
      therapeutic = $_['therapeutic']; hint = $_['hinttext']; queue = $_['oqueue'] }
  })
  # ผู้ป่วยที่มา ER ช่วงเวรทุกคน รวมคนที่ไม่มียา (มีแต่ค่าธรรมเนียม/ADVICE) — ใบสั่งยาทุกใบต้องนับลง ME ER
  $er = DbQuery ("SELECT o.vn, o.an, o.hn, DATE_FORMAT(o.vstdate,'%Y-%m-%d') AS vstdate, TIME_FORMAT(o.vsttime,'%H:%i') AS vsttime, k.department, " +
    "TRIM(CONCAT(IFNULL(p.pname,''), IFNULL(p.fname,''), ' ', IFNULL(p.lname,''))) AS ptname, p.sex, TIMESTAMPDIFF(MONTH, p.birthday, o.vstdate) AS age_m " +
    "FROM ovst o JOIN er_regist e ON e.vn=o.vn LEFT JOIN patient p ON p.hn=o.hn LEFT JOIN kskdepartment k ON k.depcode=o.main_dep " +
    "WHERE o.vstdate IN ('$d0','$d1') AND ((o.vstdate='$d0' AND o.vsttime>='$from') OR (o.vstdate='$d1' AND o.vsttime<'$to')) " +
    "ORDER BY o.vstdate, o.vsttime LIMIT 1000")
  $erVisits = @($er | ForEach-Object {
    [ordered]@{ vn = $_['vn']; an = $_['an']; hn = $_['hn']; name = $_['ptname']; date = $_['vstdate']; time = $_['vsttime']
      depName = $_['department']; sex = $_['sex']; ageM = $_['age_m'] } })
  # ใบสั่งยาที่ห้องจ่ายยา (030) กดบันทึกจ่ายแล้ว (ช่วงหัวค่ำที่ห้องยายังเปิด) — ยาไม่ได้มาจากรถยา ER
  $vns = @($rows | ForEach-Object { [HxDb]::Digits($_['vn']) } | Where-Object { $_ } | Select-Object -Unique)
  $pharmRx = @()
  if ($vns.Count) {
    $vin = ($vns | ForEach-Object { "'$_'" }) -join ','
    $pr = DbQuery ("SELECT vn, DATE_FORMAT(MIN(rx_dispenser_datetime),'%Y-%m-%d %H:%i') AS at, GROUP_CONCAT(DISTINCT staff) AS staff " +
      "FROM rx_dispenser_detail WHERE vn IN ($vin) AND depcode='030' GROUP BY vn")
    $pharmRx = @($pr | ForEach-Object { [ordered]@{ vn = $_['vn']; at = $_['at']; staff = $_['staff'] } })
  }
  # ข้อมูลประกอบการตรวจสอบ: ประวัติแพ้ยา ยาที่ได้รับใน 180 วันก่อนหน้า (ตรวจยาตีกันกับยาเดิม) และตารางยาตีกันของ รพ.
  $hns = @($rows | ForEach-Object { [HxDb]::Digits($_['hn']) } | Where-Object { $_ } | Select-Object -Unique)
  $allergy = @(); $homeMeds = @()
  if ($hns.Count) {
    $in = ($hns | ForEach-Object { "'$_'" }) -join ','
    $ar = DbQuery ("SELECT hn, agent, symptom, DATE_FORMAT(report_date,'%Y-%m-%d') AS report_date FROM opd_allergy " +
      "WHERE hn IN ($in) AND IFNULL(allergy_cancel_status,'')<>'Y'")
    $allergy = @($ar | ForEach-Object {
      [ordered]@{ hn = $_['hn']; agent = $_['agent']; symptom = $_['symptom']; date = $_['report_date'] } })
    $hfrom = $d.AddDays(-181).ToString('yyyy-MM-dd')
    $hr = DbQuery ("SELECT o.hn, o.icode, d.name, d.strength, d.dosageform, d.units, DATE_FORMAT(MAX(o.vstdate),'%Y-%m-%d') AS last FROM opitemrece o " +
      "JOIN drugitems d ON d.icode=o.icode WHERE o.hn IN ($in) AND o.vstdate>='$hfrom' AND o.vstdate<'$d0' GROUP BY o.hn, o.icode")
    $homeMeds = @($hr | ForEach-Object {
      [ordered]@{ hn = $_['hn']; icode = $_['icode']; drug = $_['name']; strength = $_['strength']; form = $_['dosageform']; units = $_['units']; last = $_['last'] } })
  }
  $dr = DbQuery "SELECT drugname1, drugname2, severity, not_allow, note FROM drug_interaction WHERE IFNULL(drug_interaction_type,1)=1"
  $ddi = @($dr | ForEach-Object {
    [ordered]@{ a = $_['drugname1']; b = $_['drugname2']; severity = $_['severity']; notAllow = $_['not_allow']; note = $_['note'] } })
  [ordered]@{ ok = $true; from = "$d0 $from"; to = "$d1 $to"; items = $items; erVisits = $erVisits; pharmRx = $pharmRx; allergy = $allergy; home = $homeMeds; ddi = $ddi }
}
function DbAdr($path) {
  $from = '2025-01-01'
  if ($path -match '[?&]from=(\d{4}-\d{2}-\d{2})') { $from = $Matches[1] }
  $rows = DbQuery ("SELECT a.patient_adr_id, a.hn, CONCAT(IFNULL(p.pname,''), IFNULL(p.fname,''), ' ', IFNULL(p.lname,'')) AS ptname, " +
    "a.department, a.an, a.report_date, a.adverse_effect_date, a.adverse_effect, a.other_dx, a.lab_pe_text, a.medication_list, " +
    "a.adr_dechallange, a.adr_rechallenge, a.adr_continue_rechallenge, a.adr_norechallenge, a.has_adr_history, " +
    "a.dx_doctor_name, a.dx_doctor_position, a.entry_officer_name, a.entry_officer_position, " +
    "pt.adr_product_type_name, se.adr_seriousness_name, oc.adr_outcome_name, po.adr_possibility_name, rt.adr_report_type_name, " +
    "ca.adr_cause_name, dt.adr_dechallenge_type_name, rct.adr_rechallenge_type_name, " +
    "(SELECT t.opd_allergy_type_name FROM opd_allergy x JOIN opd_allergy_type t ON t.opd_allergy_type_id=x.opd_allergy_type_id " +
    "  WHERE x.hn=a.hn AND ABS(DATEDIFF(x.report_date, a.report_date))<=60 ORDER BY ABS(DATEDIFF(x.report_date, a.report_date)) LIMIT 1) AS allergy_type " +
    "FROM patient_adr a LEFT JOIN patient p ON p.hn=a.hn " +
    "LEFT JOIN adr_product_type pt ON pt.adr_product_type_id=a.adr_product_type_id " +
    "LEFT JOIN adr_seriousness se ON se.adr_seriousness_id=a.adr_seriousness_id " +
    "LEFT JOIN adr_outcome oc ON oc.adr_outcome_id=a.adr_outcome_id " +
    "LEFT JOIN adr_possibility po ON po.adr_possibility_id=a.adr_possibility_id " +
    "LEFT JOIN adr_report_type rt ON rt.adr_report_type_id=a.adr_report_type_id " +
    "LEFT JOIN adr_cause ca ON ca.adr_cause_id=a.adr_cause_id " +
    "LEFT JOIN adr_dechallenge_type dt ON dt.adr_dechallenge_type_id=a.adr_dechallenge_type_id " +
    "LEFT JOIN adr_rechallenge_type rct ON rct.adr_rechallenge_type_id=a.adr_rechallenge_type_id " +
    "WHERE a.report_date>='$from' ORDER BY a.report_date DESC, a.patient_adr_id DESC LIMIT 500")
  $meds = @{}
  if ($rows.Count) {
    $ids = ($rows | ForEach-Object { [HxDb]::Digits($_['patient_adr_id']) } | Where-Object { $_ }) -join ','
    foreach ($m in (DbQuery ("SELECT m.patient_adr_id, t.adr_medication_type_name, m.medication_name, m.medication_begin_date, m.medication_end_date, m.medication_icd, m.medication_idr " +
        "FROM patient_adr_medication m LEFT JOIN adr_medication_type t ON t.adr_medication_type_id=m.adr_medication_type_id WHERE m.patient_adr_id IN ($ids) ORDER BY m.patient_adr_medication_id"))) {
      $k = $m['patient_adr_id']
      if (-not $meds.ContainsKey($k)) { $meds[$k] = New-Object System.Collections.ArrayList }
      [void]$meds[$k].Add([ordered]@{ role = $m['adr_medication_type_name']; name = $m['medication_name']; begin = $m['medication_begin_date']
        end = $m['medication_end_date']; indication = $m['medication_icd']; usage = $m['medication_idr'] })
    }
  }
  $items = @($rows | ForEach-Object {
    [ordered]@{ id = $_['patient_adr_id']; hn = $_['hn']; name = $_['ptname'].Trim(); dept = $_['department']; an = $_['an']
      reportDate = $_['report_date']; onsetDate = $_['adverse_effect_date']; effect = $_['adverse_effect']; otherDx = $_['other_dx']
      labPe = $_['lab_pe_text']; drugs = $_['medication_list']; productType = $_['adr_product_type_name']; seriousness = $_['adr_seriousness_name']
      outcome = $_['adr_outcome_name']; possibility = $_['adr_possibility_name']; reportType = $_['adr_report_type_name']; cause = $_['adr_cause_name']
      dechallenge = $_['adr_dechallange']; dechallengeType = $_['adr_dechallenge_type_name']; rechallenge = $_['adr_rechallenge']
      rechallengeType = $_['adr_rechallenge_type_name']; continueRechallenge = $_['adr_continue_rechallenge']; noRechallenge = $_['adr_norechallenge']
      hasHistory = $_['has_adr_history']; doctor = $_['dx_doctor_name']; doctorPosition = $_['dx_doctor_position']
      officer = $_['entry_officer_name']; officerPosition = $_['entry_officer_position']; allergyType = $_['allergy_type']
      meds = @(if ($meds.ContainsKey($_['patient_adr_id'])) { $meds[$_['patient_adr_id']] }) }
  })
  [ordered]@{ ok = $true; items = $items }
}

# ── DM remission ─────────────────────────────────────────────
# lab ที่ใช้ในฟอร์ม DM remission → รหัส lab ใน HOSxP (หลายรหัส = ชุดเก่า/ใหม่ ใช้ค่าล่าสุดของรหัสใดก็ได้)
$DM_LABS = [ordered]@{ hba1c = '3119'; fbs = '3117'; ldl = '3191,3008,3122'; tc = '3038,3005,3120'; tg = '3006,3039,3123'
  cr = '3036,3003,3118'; egfr = '3189'; urineAlb = '3138' }
$DM_CLINIC = "'032'"
# ยาลดน้ำตาล (ไม่นับอินซูลินฉีดครั้งเดียว STAT ที่ ER)
$GLUCOSE_DRUG_RE = 'metformin|glipizide|glibencl|gliclaz|glimepir|pioglit|gliptin|gliflozin|acarbose|insulin|mixtard|lantus|glargine|novomix|novorapid|humulin|gensulin|actrapid|insulatard|levemir|toujeo|tresiba|glp|liraglutide|semaglutide|dulaglutide'

function DbDmRoster {
  $rows = DbQuery ("SELECT a.hn, CONCAT(IFNULL(p.pname,''), IFNULL(p.fname,''), ' ', IFNULL(p.lname,'')) AS ptname, p.birthday, p.sex, " +
    "MIN(a.vstdate) AS first_date, MAX(a.vstdate) AS last_date, MAX(IF(a.nextdate>=CURDATE() AND (a.oapp_status_id IS NULL OR a.oapp_status_id=1), a.nextdate, NULL)) AS next_date " +
    "FROM oapp a LEFT JOIN patient p ON p.hn=a.hn WHERE a.clinic IN ($DM_CLINIC) GROUP BY a.hn ORDER BY MIN(a.vstdate)")
  [ordered]@{ ok = $true; patients = @($rows | ForEach-Object { [ordered]@{ hn = $_['hn']; name = $_['ptname'].Trim(); birthday = $_['birthday']; sex = $_['sex']
    firstDate = $_['first_date']; lastDate = $_['last_date']; nextDate = $_['next_date'] } }) }
}

# วันเข้าคลินิก NCDs remission ของ HN นี้ + วันที่ขอเพิ่ม (?dates=YYYY-MM-DD,... เช่น visit ที่บันทึกไว้แล้วในหน้าเว็บ)
# ต่อวัน: สัญญาณชีพ (opdscreen), lab ล่าสุดภายใน 60 วันก่อนวันนั้น, ยาที่ได้ (พร้อมรหัสวิธีใช้ให้หน้าเว็บแปลงเป็น "1x2 pc")
# baseline = visit ล่าสุดก่อนเข้าคลินิกครั้งแรกที่มียาลดน้ำตาล (ค่ายาก่อนเข้าโครงการ) · dx = โรคเรื้อรังจาก ICD-10 2 ปี
# ดึงทีละตาราง (ไม่ query ต่อวัน) — 1 คนใช้เวลา < 1 วินาที
function DbDmVisits($hn, $path) {
  $clinic = DbQuery ("SELECT DISTINCT d FROM (SELECT a.vstdate AS d FROM oapp a WHERE a.hn='$hn' AND a.clinic IN ($DM_CLINIC) " +
    "UNION SELECT o.vstdate FROM oapp a JOIN ovst o ON o.vn=a.visit_vn WHERE a.hn='$hn' AND a.clinic IN ($DM_CLINIC)) x WHERE d<=CURDATE()")
  $clinicDates = @($clinic | ForEach-Object { $_['d'] })
  $extra = @()
  if ($path -match '[?&]dates=([0-9,\-]+)') { $extra = @($Matches[1] -split ',' | Where-Object { $_ -match '^\d{4}-\d{2}-\d{2}$' }) }
  $first = ($clinicDates + $extra | Sort-Object | Select-Object -First 1)
  # baseline: visit ล่าสุดก่อนวันแรกที่มียาลดน้ำตาล
  $base = $null
  if ($first) {
    $b = DbQuery ("SELECT MAX(r.vstdate) AS d FROM opitemrece r JOIN drugitems d ON d.icode=r.icode WHERE r.hn='$hn' AND r.vstdate<'$first' " +
      "AND r.vstdate>=DATE_SUB('$first', INTERVAL 1 YEAR) AND (r.an IS NULL OR r.an='') AND d.name REGEXP '$GLUCOSE_DRUG_RE' AND d.name NOT LIKE '%STAT%'")
    if ($b.Count -and $b[0]['d']) { $base = $b[0]['d'] }
  }
  $all = @($clinicDates + $extra + @($base) | Where-Object { $_ } | Sort-Object -Unique -Descending)
  $visits = New-Object System.Collections.ArrayList
  $dx = @()
  if ($all.Count) {
    $in = ($all | ForEach-Object { "'$_'" }) -join ','
    $vit = DbQuery ("SELECT o.vstdate, s.bw, s.height, s.bmi, s.bps, s.bpd, s.fbs, s.waist FROM opdscreen s JOIN ovst o ON o.vn=s.vn " +
      "WHERE o.hn='$hn' AND o.vstdate IN ($in) ORDER BY o.vstdate, (s.bw IS NULL), o.vsttime")
    $drugs = DbQuery ("SELECT r.vstdate, $DRUG_COLS, d.unitprice, u.iperdose, u.opi_frequency_code, u.opi_time_code $DRUG_JOIN " +
      "WHERE r.hn='$hn' AND r.vstdate IN ($in) AND (r.an IS NULL OR r.an='') ORDER BY r.vstdate, r.vn, r.item_no")
    $codes = ($DM_LABS.Values -join ',')
    $oldest = $all[-1]
    $labs = DbQuery ("SELECT h.order_date, o.lab_items_code, o.lab_order_result FROM lab_head h JOIN lab_order o ON o.lab_order_number=h.lab_order_number " +
      "WHERE h.hn='$hn' AND o.lab_items_code IN ($codes) AND h.order_date>=DATE_SUB('$oldest', INTERVAL 60 DAY) " +
      "AND o.lab_order_result IS NOT NULL AND o.lab_order_result<>'' ORDER BY h.order_date DESC")
    $dxr = DbQuery ("SELECT DISTINCT LEFT(icd10,3) AS c FROM ovstdiag WHERE hn='$hn' AND vstdate>=CURDATE()-INTERVAL 2 YEAR " +
      "AND LEFT(icd10,3) IN ('E11','E10','E14','I10','I11','E78','N18','I25','I63','J44','J45','E66','M10','K76')")
    $dx = @($dxr | ForEach-Object { $_['c'] })
    foreach ($d in $all) {
      $dd = [DateTime]::Parse($d)
      $v = $vit | Where-Object { $_['vstdate'] -eq $d } | Select-Object -First 1
      $lab = [ordered]@{}; $labDate = [ordered]@{}
      foreach ($k in $DM_LABS.Keys) {
        $set = $DM_LABS[$k] -split ','
        $hit = $labs | Where-Object { $set -contains $_['lab_items_code'] -and ([DateTime]::Parse($_['order_date']) -le $dd) -and (($dd - [DateTime]::Parse($_['order_date'])).TotalDays -le 60) } | Select-Object -First 1
        if ($hit) { $lab[$k] = $hit['lab_order_result']; $labDate[$k] = $hit['order_date'] }
      }
      $kind = if ($d -eq $base -and $clinicDates -notcontains $d) { 'baseline' } elseif ($clinicDates -contains $d) { 'clinic' } else { 'requested' }
      [void]$visits.Add([ordered]@{ date = $d; kind = $kind
        weight = $(if ($v) { $v['bw'] }); height = $(if ($v) { $v['height'] }); bmi = $(if ($v) { $v['bmi'] })
        bp = $(if ($v -and $v['bps'] -and $v['bpd']) { "$([int][double]$v['bps'])/$([int][double]$v['bpd'])" } else { '' }); dtx = $(if ($v) { $v['fbs'] })
        lab = $lab; labDate = $labDate
        drugs = @($drugs | Where-Object { $_['vstdate'] -eq $d } | ForEach-Object { [ordered]@{ name = (@($_['name'], $_['strength']) -join ' ').Trim(); unit = $_['units']
          qty = $_['qty']; price = $_['unitprice']; usage = $_['usage_text']; form = $_['dosageform']
          dose = $_['iperdose']; freqCode = $_['opi_frequency_code']; timeCode = $_['opi_time_code'] } }) })
    }
  }
  [ordered]@{ ok = $true; hn = $hn; visits = $visits; baselineDate = $base; dx = $dx }
}

function DbDmScreen {
  $cohort = "SELECT DISTINCT hn FROM oapp WHERE clinic IN ('023','001') AND nextdate>=CURDATE()-INTERVAL 1 YEAR"
  $pts = DbQuery ("SELECT p.hn, CONCAT(IFNULL(p.pname,''), IFNULL(p.fname,''), ' ', IFNULL(p.lname,'')) AS ptname, p.birthday, p.sex, " +
    "(SELECT MIN(a.nextdate) FROM oapp a WHERE a.hn=p.hn AND a.clinic IN ('023','001') AND a.nextdate>=CURDATE() AND (a.oapp_status_id IS NULL OR a.oapp_status_id=1)) AS next_dm, " +
    "(SELECT COUNT(*) FROM oapp a WHERE a.hn=p.hn AND a.clinic IN ($DM_CLINIC)) AS in_remission " +
    "FROM patient p WHERE p.hn IN ($cohort)")
  $a1c = DbQuery ("SELECT h.hn, h.order_date, o.lab_order_result FROM lab_head h JOIN lab_order o ON o.lab_order_number=h.lab_order_number " +
    "WHERE o.lab_items_code='3119' AND h.order_date>=CURDATE()-INTERVAL 2 YEAR AND h.hn IN ($cohort) ORDER BY h.order_date")
  # ปีที่เริ่มเป็นเบาหวาน: ทะเบียนคลินิก DM (begin_year พ.ศ., regdate) + วันแรกที่มีรหัส E10–E14 — หน้าเว็บใช้ค่าที่เก่าที่สุด
  $dmReg = DbQuery "SELECT hn, regdate, begin_year FROM clinicmember WHERE clinic='001' AND hn IN ($cohort)"
  $dmDx = DbQuery ("SELECT hn, MIN(vstdate) AS fd FROM ovstdiag WHERE icd10>='E10' AND icd10<'E15' AND vstdate>'1990-01-01' " +
    "AND hn IN ($cohort) GROUP BY hn")
  $icodes = DbQuery "SELECT icode FROM drugitems WHERE name REGEXP '$GLUCOSE_DRUG_RE' AND name NOT LIKE '%STAT%'"
  $ic = ($icodes | ForEach-Object { "'" + [HxDb]::Digits($_['icode']) + "'" } | Where-Object { $_ -ne "''" }) -join ','
  $rx = @()
  if ($ic) {
    $rx = DbQuery ("SELECT r.hn, IFNULL(r.rxdate, r.vstdate) AS d, d.name, r.qty, u.iperday, u.iperdose, (r.an IS NOT NULL AND r.an<>'') AS ipd, " +
      "(SELECT DATEDIFF(MAX(a.nextdate), r.vstdate) FROM oapp a WHERE a.vn=r.vn) AS appt_days " +
      "FROM opitemrece r JOIN drugitems d ON d.icode=r.icode LEFT JOIN drugusage u ON u.drugusage=r.drugusage " +
      "WHERE r.icode IN ($ic) AND IFNULL(r.rxdate, r.vstdate)>=CURDATE()-INTERVAL 2 YEAR AND r.hn IN ($cohort)")
  }
  $byHn = @{}
  foreach ($p in $pts) { $byHn[$p['hn']] = [ordered]@{ hn = $p['hn']; name = $p['ptname'].Trim(); birthday = $p['birthday']; sex = $p['sex']
    nextDm = $p['next_dm']; inRemission = ([int]$p['in_remission'] -gt 0); dmReg = $null; dmBeginYear = $null; dmFirstDx = $null; a1c = New-Object System.Collections.ArrayList; rx = New-Object System.Collections.ArrayList } }
  foreach ($r in $dmReg) { if ($byHn.ContainsKey($r['hn'])) { $byHn[$r['hn']].dmReg = $r['regdate']; $byHn[$r['hn']].dmBeginYear = $r['begin_year'] } }
  foreach ($r in $dmDx) { if ($byHn.ContainsKey($r['hn'])) { $byHn[$r['hn']].dmFirstDx = $r['fd'] } }
  foreach ($r in $a1c) { if ($byHn.ContainsKey($r['hn'])) { [void]$byHn[$r['hn']].a1c.Add(@($r['order_date'], $r['lab_order_result'])) } }
  foreach ($r in $rx) {
    if (-not $byHn.ContainsKey($r['hn'])) { continue }
    $perDay = 0.0
    try { if ($r['iperday'] -and $r['iperdose']) { $perDay = [double]$r['iperday'] * [double]$r['iperdose'] } } catch {}
    [void]$byHn[$r['hn']].rx.Add(@($r['d'], $r['name'], $r['qty'], $perDay, $r['appt_days'], ($r['ipd'] -eq '1')))
  }
  [ordered]@{ ok = $true; patients = @($byHn.Values) }
}

# ── สติกเกอร์ยา (พิมพ์เองเมื่อ VN ถูกพยาบาลล็อกอยู่ใน HOSxP) ──
function DbRxQueue {
  $rows = DbQuery ("SELECT o.vn, o.hn, DATE_FORMAT(o.vstdate,'%Y-%m-%d') AS vstdate, TIME_FORMAT(o.vsttime,'%H:%i') AS vsttime, o.oqueue, " +
    "TRIM(CONCAT(IFNULL(p.pname,''), IFNULL(p.fname,''), ' ', IFNULL(p.lname,''))) AS ptname, k.department, " +
    "(SELECT COUNT(*) FROM opitemrece r JOIN drugitems d ON d.icode=r.icode WHERE r.vn=o.vn) AS ndrug, " +
    "(SELECT DATE_FORMAT(MAX(r.last_modified),'%H:%i') FROM opitemrece r WHERE r.vn=o.vn) AS lastmod, " +
    "l.lock_staff, l.lock_computer, DATE_FORMAT(l.lock_date_time,'%H:%i') AS lock_time " +
    "FROM ovst o LEFT JOIN patient p ON p.hn=o.hn LEFT JOIN kskdepartment k ON k.depcode=o.cur_dep LEFT JOIN vn_lock l ON l.vn=o.vn " +
    "WHERE o.vstdate IN (CURDATE(), CURDATE() - INTERVAL 1 DAY) ORDER BY o.vstdate DESC, o.vsttime DESC LIMIT 150")
  $items = @($rows | Where-Object { [int]$_['ndrug'] -gt 0 } | Select-Object -First 40 | ForEach-Object {
    [ordered]@{ vn = $_['vn']; hn = $_['hn']; date = $_['vstdate']; time = $_['vsttime']; queue = $_['oqueue']; name = $_['ptname']
      dep = $_['department']; ndrug = [int]$_['ndrug']; lastmod = $_['lastmod']
      lockStaff = $_['lock_staff']; lockComputer = $_['lock_computer']; lockTime = $_['lock_time'] } })
  [ordered]@{ ok = $true; items = $items; now = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') }
}
function DbIpdList {
  # อายุ น้ำหนัก (ipt.bw เป็นกรัม ไม่มีใช้ opdscreen ของ visit แรกรับ) โรคประจำตัว (pmh ตอนแรกรับ) — ใช้กับหัวสติกเกอร์ MR
  $rows = DbQuery ("SELECT i.an, i.hn, DATE_FORMAT(i.regdate,'%Y-%m-%d') AS regdate, TIME_FORMAT(i.regtime,'%H:%i') AS regtime, i.ward, w.name AS ward_name, " +
    "a.bedno, a.roomno, CONCAT(TRIM(IFNULL(p.pname,'')), TRIM(IFNULL(p.fname,'')), '  ', TRIM(IFNULL(p.lname,''))) AS ptname, " +
    "s.age_y, s.age_m, i.bw, o.bw AS obw, o.pmh " +
    "FROM ipt i LEFT JOIN iptadm a ON a.an=i.an LEFT JOIN ward w ON w.ward=i.ward LEFT JOIN patient p ON p.hn=i.hn " +
    "LEFT JOIN an_stat s ON s.an=i.an LEFT JOIN opdscreen o ON o.vn=i.vn " +
    "WHERE i.dchdate IS NULL AND i.regdate>=CURDATE() - INTERVAL 1 YEAR ORDER BY i.ward, a.bedno LIMIT 300")
  $al = @{}; $cl = @{}
  if ($rows.Count) {
    $hns = ($rows | ForEach-Object { "'" + [HxDb]::Digits($_['hn']) + "'" } | Select-Object -Unique) -join ','
    $ar = DbQuery ("SELECT hn, agent FROM opd_allergy WHERE hn IN ($hns) AND IFNULL(allergy_cancel_status,'')<>'Y' ORDER BY hn, report_date")
    foreach ($x in $ar) { $a = "$($x['agent'])".Trim(); if ($a) { $al["$($x['hn'])"] = @($al["$($x['hn'])"]) + $a } }
    $cr = DbQuery ("SELECT m.hn, c.name FROM clinicmember m JOIN clinic c ON c.clinic=m.clinic WHERE m.hn IN ($hns) AND IFNULL(m.discharge,'')<>'Y'")
    foreach ($x in $cr) { $c = "$($x['name'])".Trim(); if ($c) { $cl["$($x['hn'])"] = @($cl["$($x['hn'])"]) + $c } }
  }
  [ordered]@{ ok = $true; items = @($rows | ForEach-Object {
    $bw = if ("$($_['bw'])" -match '^\d+(\.\d+)?$' -and [double]$_['bw'] -gt 0) { [math]::Round([double]$_['bw'] / 1000, 2) }
      elseif ("$($_['obw'])" -match '^\d+(\.\d+)?$' -and [double]$_['obw'] -gt 0) { [math]::Round([double]$_['obw'], 2) } else { $null }
    [ordered]@{ an = $_['an']; hn = $_['hn']; regdate = $_['regdate']; regtime = $_['regtime']; ward = $_['ward']; wardName = $_['ward_name']
      bed = $_['bedno']; room = $_['roomno']; name = $_['ptname']; ageY = $_['age_y']; ageM = $_['age_m']; bw = $bw
      pmh = ("$($_['pmh'])" -replace '\s+', ' ').Trim(); allergy = @($al["$($_['hn'])"] | Where-Object { $_ }); clinics = @($cl["$($_['hn'])"] | Where-Object { $_ }) } }) }
}
# เครื่องที่ให้พิมพ์สรุปยากลับบ้านอัตโนมัติ: ชื่อเครื่อง (COMPUTERNAME) อยู่ใน hme-station.txt ในโฟลเดอร์ bridge
# ไฟล์นี้ไม่อยู่ในตัวติดตั้ง — เครื่องอื่นจึงไม่พิมพ์อัตโนมัติจนกว่าจะเพิ่มชื่อเครื่องเอง (หน้าเว็บปิดปุ่มพิมพ์อัตโนมัติให้ด้วย)
function HmeStation {
  $f = Join-Path $PSScriptRoot 'hme-station.txt'
  if (-not (Test-Path $f)) { return $false }
  return [bool](@(Get-Content $f -Encoding UTF8 | ForEach-Object { $_.Trim() }) -contains $env:COMPUTERNAME)
}
function DbHme {
  $ords = DbQuery ("SELECT n.an, n.order_no, DATE_FORMAT(n.rxdate,'%Y-%m-%d') AS rxdate, TIME_FORMAT(n.rxtime,'%H:%i') AS rxtime, n.entry_staff, " +
    "i.hn, DATE_FORMAT(i.dchdate,'%Y-%m-%d') AS dchdate, w.name AS ward_name, a.bedno, " +
    "CONCAT(TRIM(IFNULL(p.pname,'')), TRIM(IFNULL(p.fname,'')), '  ', TRIM(IFNULL(p.lname,''))) AS ptname, s.age_y " +
    "FROM ipt_order_no n JOIN ipt i ON i.an=n.an LEFT JOIN iptadm a ON a.an=n.an LEFT JOIN ward w ON w.ward=i.ward " +
    "LEFT JOIN patient p ON p.hn=i.hn LEFT JOIN an_stat s ON s.an=n.an " +
    "WHERE n.order_type='HMe' AND n.rxdate IN (CURDATE(), CURDATE() - INTERVAL 1 DAY) ORDER BY n.rxdate DESC, n.rxtime DESC LIMIT 60")
  $out = @()
  if ($ords.Count) {
    $ans = ($ords | ForEach-Object { "'" + [HxDb]::Digits($_['an']) + "'" } | Select-Object -Unique) -join ','
    $nos = ($ords | ForEach-Object { [HxDb]::Digits($_['order_no']) } | Where-Object { $_ } | Select-Object -Unique) -join ','
    # วิธีใช้ตามแบบสติกเกอร์ HOSxP: opi_dispense.usage_line1-3 ถ้า usage_lock='Y' ไม่งั้น drugusage.name1-3
    $items = DbQuery ("SELECT r.an, r.order_no, r.icode, r.qty, DATE_FORMAT(r.last_modified,'%Y-%m-%d %H:%i:%s') AS lastmod, " +
      "d.name, d.strength, d.units, d.dosageform, TRIM(IFNULL(d.name_print,'')) AS name_print, " +
      "IF(od.usage_lock='Y', od.usage_line1, IF(r.sp_use<>'', sp.name1, u.name1)) AS line1, " +
      "IF(od.usage_lock='Y', od.usage_line2, IF(r.sp_use<>'', sp.name2, u.name2)) AS line2, " +
      "IF(od.usage_lock='Y', od.usage_line3, IF(r.sp_use<>'', sp.name3, u.name3)) AS line3 " +
      "FROM opitemrece r JOIN drugitems d ON d.icode=r.icode LEFT JOIN drugusage u ON u.drugusage=r.drugusage " +
      "LEFT JOIN sp_use sp ON sp.sp_use=r.sp_use LEFT JOIN opi_dispense od ON od.hos_guid=r.hos_guid " +
      "WHERE r.an IN ($ans) AND r.order_no IN ($nos) ORDER BY r.an, r.order_no, r.item_no")
    $out = @($ords | ForEach-Object {
      $an = $_['an']; $no = $_['order_no']
      $its = @($items | Where-Object { $_['an'] -eq $an -and $_['order_no'] -eq $no })
      [ordered]@{ an = $an; orderNo = $no; date = $_['rxdate']; time = $_['rxtime']; staff = $_['entry_staff']; hn = $_['hn']
        dchdate = $_['dchdate']; ward = $_['ward_name']; bed = $_['bedno']; name = $_['ptname']; ageY = $_['age_y']
        lastmod = (@($its | ForEach-Object { $_['lastmod'] }) | Sort-Object | Select-Object -Last 1)
        items = @($its | ForEach-Object {
          [ordered]@{ icode = $_['icode']; qty = $_['qty']; name = $_['name']; strength = $_['strength']; units = $_['units']
            form = $_['dosageform']; namePrint = $_['name_print']; line1 = $_['line1']; line2 = $_['line2']; line3 = $_['line3'] } }) } })
  }
  [ordered]@{ ok = $true; orders = $out; now = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'); station = (HmeStation) }
}
function DbRxSticker($hn) {
  $vis = DbQuery ("SELECT o.vn, DATE_FORMAT(o.vstdate,'%Y-%m-%d') AS vstdate, TIME_FORMAT(o.vsttime,'%H:%i') AS vsttime, o.oqueue, " +
    "TRIM(CONCAT(IFNULL(p.pname,''), IFNULL(p.fname,''), ' ', IFNULL(p.lname,''))) AS ptname, v.age_y, " +
    "l.lock_staff, l.lock_computer, DATE_FORMAT(l.lock_date_time,'%H:%i') AS lock_time " +
    "FROM ovst o LEFT JOIN patient p ON p.hn=o.hn LEFT JOIN vn_stat v ON v.vn=o.vn LEFT JOIN vn_lock l ON l.vn=o.vn " +
    "WHERE o.hn='$hn' AND o.vstdate IN (CURDATE(), CURDATE() - INTERVAL 1 DAY) ORDER BY o.vstdate DESC, o.vsttime DESC")
  $visits = @()
  if ($vis.Count) {
    $vns = ($vis | ForEach-Object { "'" + [HxDb]::Digits($_['vn']) + "'" }) -join ','
    # ตาม StickerDetailReport.rtm: วิธีใช้ = opi_dispense.usage_line1-3 ถ้า usage_lock='Y' ไม่งั้น drugusage.name1-3
    $items = DbQuery ("SELECT o.vn, o.hos_guid, o.icode, o.qty, TIME_FORMAT(o.rxtime,'%H:%i') AS rxtime, DATE_FORMAT(o.last_modified,'%H:%i') AS lastmod, k.department, " +
      "d.name, d.strength, d.units, d.dosageform, TRIM(IFNULL(d.name_print,'')) AS name_print, d.thai_name, d.therapeutic, d.pregnancy, " +
      "d.light_protect, d.antibiotic, d.print_sticker_pq, d.lockprint, d.special_advice_text, d.precaution_advice_text, h.hinttext, " +
      "IF(od.usage_lock='Y', od.usage_line1, IF(o.sp_use<>'', sp.name1, u.name1)) AS line1, " +
      "IF(od.usage_lock='Y', od.usage_line2, IF(o.sp_use<>'', sp.name2, u.name2)) AS line2, " +
      "IF(od.usage_lock='Y', od.usage_line3, IF(o.sp_use<>'', sp.name3, u.name3)) AS line3 " +
      "FROM opitemrece o JOIN drugitems d ON d.icode=o.icode LEFT JOIN drughint h ON h.hc=d.hintcode AND IFNULL(d.hintcode,'')<>'' " +
      "LEFT JOIN drugusage u ON u.drugusage=o.drugusage LEFT JOIN sp_use sp ON sp.sp_use=o.sp_use " +
      "LEFT JOIN opi_dispense od ON od.hos_guid=o.hos_guid LEFT JOIN kskdepartment k ON k.depcode=o.dep_code " +
      "WHERE o.vn IN ($vns) ORDER BY o.vn, o.item_no")
    $visits = @($vis | ForEach-Object {
      $vn = $_['vn']
      [ordered]@{ vn = $vn; date = $_['vstdate']; time = $_['vsttime']; queue = $_['oqueue']; name = $_['ptname']; ageY = $_['age_y']
        lockStaff = $_['lock_staff']; lockComputer = $_['lock_computer']; lockTime = $_['lock_time']
        items = @($items | Where-Object { $_['vn'] -eq $vn } | ForEach-Object {
          [ordered]@{ guid = $_['hos_guid']; icode = $_['icode']; qty = $_['qty']; rxtime = $_['rxtime']; lastmod = $_['lastmod']; dep = $_['department']
            name = $_['name']; strength = $_['strength']; units = $_['units']; form = $_['dosageform']; namePrint = $_['name_print']
            thaiName = $_['thai_name']; therapeutic = $_['therapeutic']; pregnancy = $_['pregnancy']; light = $_['light_protect']
            antibiotic = $_['antibiotic']; pq = $_['print_sticker_pq']; lockprint = $_['lockprint']; hint = $_['hinttext']
            advice = (@($_['special_advice_text'], $_['precaution_advice_text']) | Where-Object { $_ -and $_.Trim() }) -join "`n"
            line1 = $_['line1']; line2 = $_['line2']; line3 = $_['line3'] } }) } })
  }
  [ordered]@{ ok = $true; hn = $hn; visits = $visits; now = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss') }
}

function DbErRx($hn, $path) {
  if ($path -notmatch '[?&]date=(\d{4}-\d{2}-\d{2})') { throw 'ต้องระบุ date=YYYY-MM-DD' }
  $d = [datetime]::ParseExact($Matches[1], 'yyyy-MM-dd', $null)
  $d0 = $d.AddDays(-1).ToString('yyyy-MM-dd'); $d1 = $d.ToString('yyyy-MM-dd')
  $p = DbQuery "SELECT pname, fname, lname, DATE_FORMAT(birthday,'%Y-%m-%d') AS birthday, sex FROM patient WHERE hn='$hn' LIMIT 1"
  if (-not $p.Count) { return [ordered]@{ ok = $false; hn = $hn; error = 'ไม่พบ HN นี้' } }
  # ใช้ ix_hn แล้วกรอง rxdate — ใบสั่งหนึ่งใบ = VN (OPD/ER) หรือ AN+วันที่ (ผู้ป่วยใน) พร้อมรายการยาในใบนั้น
  $rows = DbQuery ("SELECT o.vn, o.an, DATE_FORMAT(o.rxdate,'%Y-%m-%d') AS rxdate, TIME_FORMAT(o.rxtime,'%H:%i') AS rxtime, " +
    "k.department, TIMESTAMPDIFF(YEAR, pt.birthday, o.rxdate) AS age, o.icode, d.name, d.strength, d.units, d.dosageform, o.qty, " +
    "TRIM(IF(o.sp_use IS NOT NULL AND o.sp_use<>'', CONCAT_WS(' ', sp.name1, sp.name2, sp.name3), CONCAT_WS(' ', u.name1, u.name2, u.name3))) AS usage_text " +
    "FROM opitemrece o JOIN drugitems d ON d.icode=o.icode LEFT JOIN kskdepartment k ON k.depcode=o.dep_code LEFT JOIN patient pt ON pt.hn=o.hn " +
    "LEFT JOIN drugusage u ON u.drugusage=o.drugusage LEFT JOIN sp_use sp ON sp.sp_use=o.sp_use " +
    "WHERE o.hn='$hn' AND o.rxdate IN ('$d0','$d1') ORDER BY o.rxdate, o.rxtime, o.item_no")
  $groups = [ordered]@{}
  foreach ($r in $rows) {
    $k = "$($r['vn'])|$($r['an'])|$($r['rxdate'])"
    if (-not $groups.Contains($k)) {
      $groups[$k] = [ordered]@{ vn = $r['vn']; an = $r['an']; date = $r['rxdate']; time = $r['rxtime']; n = 0; dep = ''; age = $r['age']; deps = @(); items = @() }
    }
    $g = $groups[$k]; $g.n++
    if ($r['department'] -and $g.deps -notcontains $r['department']) { $g.deps += $r['department'] }
    $g.items += [ordered]@{ icode = $r['icode']; name = $r['name']; strength = $r['strength']; units = $r['units']; form = $r['dosageform']
      qty = $r['qty']; usage = $r['usage_text']; time = $r['rxtime'] }
  }
  $x = $p[0]
  [ordered]@{ ok = $true; hn = $hn; name = ("$($x['pname'])$($x['fname']) $($x['lname'])").Trim(); birthday = $x['birthday']; sex = $x['sex']
    rx = @($groups.Values | ForEach-Object { $_.dep = $_.deps -join ','; $_.Remove('deps'); $_ }) }
}
# ยาเดิมสำหรับใบ MR (ผู้ใช้ขอ 2026-10-21 — เดิมเอายาทุก visit OPD ใน 1 ปีมารวม ยา ER/ยาบรรเทาอาการปนมาเยอะ):
#   visit ที่มาตามนัด (oapp) ครั้งล่าสุดที่มียาของแต่ละคลินิก ใน 1 ปีก่อน admit — ทุกคลินิก ไม่ใช่แค่ DM/HT/COPD
#   (2026-10-22: HN 4802454 เริ่ม Lasix/Losartan ที่นัด F/U คลินิก 000 ตรวจโรคทั่วไป แล้วไม่ถูกดึง; ยาบรรเทาอาการใน visit
#   แบบนี้หน้าเว็บไม่ติ๊กให้อยู่แล้วตามจำนวนวันที่ยาพอ)
#   + ยากลับบ้าน (HMe) ของการนอน รพ. ครั้งล่าสุดก่อน admit นี้ — หน้าเว็บใช้ D/C เป็นจุดตัด
#   chronic = $true บอกหน้าเว็บว่าเป็นข้อมูลแบบนี้ (bridge รุ่นเก่าส่งทุก visit)
function DbMrMeds($hn, $path) {
  $an = if ($path -match '[?&]an=(\d+)') { $matches[1] } else { '' }
  $ipt = DbQuery "SELECT an, vn, DATE_FORMAT(regdate,'%Y-%m-%d') AS regdate FROM ipt WHERE an='$an' AND hn='$hn' LIMIT 1"
  if (-not $ipt.Count) { throw 'ไม่พบ AN นี้' }
  $reg = $ipt[0]['regdate']; $avn = [HxDb]::Digits($ipt[0]['vn'])
  # o.hn='$hn' ใน WHERE: เงื่อนไข OR ใน JOIN ทำให้ MySQL ไล่ ovst ทั้งตาราง (1.2 ล้านแถว) ต่อนัดทุกรายการ — คนไข้นัดเยอะ
  #   ใช้ >20 วิ เกินเวลารอของ bridge แล้วหน้าเว็บขึ้นว่าไม่ได้ต่อ bridge (2026-11-02: AN 690001206 20.9 วิ → 0.01 วิ ผลเท่าเดิม)
  $vis = DbQuery ("SELECT a.clinic, c.name AS clinic_name, o.vn FROM oapp a JOIN clinic c ON c.clinic=a.clinic " +
    "JOIN ovst o ON o.vn=a.visit_vn OR o.vn=a.vn OR ((a.visit_vn IS NULL OR a.visit_vn='') AND o.hn=a.hn AND o.vstdate=a.nextdate) " +
    "WHERE a.hn='$hn' AND o.hn='$hn' AND o.vstdate>='$reg' - INTERVAL 365 DAY AND o.vstdate<='$reg' AND o.vn<>'$avn' " +
    "ORDER BY o.vstdate DESC, o.vn DESC LIMIT 40")
  $items = New-Object System.Collections.ArrayList
  if ($vis.Count) {
    $vns = ($vis | ForEach-Object { "'" + [HxDb]::Digits($_['vn']) + "'" } | Select-Object -Unique) -join ','
    $all = DbQuery ("SELECT r.vn, DATE_FORMAT(r.vstdate,'%Y-%m-%d') AS d, $DRUG_COLS, TRIM(IFNULL(d.name_print,'')) AS name_print " +
      "$DRUG_JOIN WHERE r.vn IN ($vns) AND (r.an IS NULL OR r.an='') ORDER BY r.vstdate DESC, r.vn DESC, r.item_no")
    # แต่ละคลินิกเอา visit ล่าสุดที่มียา (นัด LAB บางครั้งไม่มียา) — visit เดียวกันนัดหลายคลินิกเอาครั้งเดียว
    $seen = @{}; $used = @{}
    foreach ($v in $vis) {
      $vn = "$($v['vn'])"
      if ($seen.ContainsKey("$($v['clinic'])")) { continue }
      $rs = @($all | Where-Object { "$($_['vn'])" -eq $vn })
      if (-not $rs.Count) { continue }
      $seen["$($v['clinic'])"] = $true
      if ($used.ContainsKey($vn)) { continue }
      $used[$vn] = $true
      foreach ($r in $rs) { [void]$items.Add(@{ r = $r; dep = "นัด $($v['clinic_name'])" }) }
    }
  }
  $last = DbQuery ("SELECT an FROM ipt WHERE hn='$hn' AND an<>'$an' AND dchdate IS NOT NULL AND dchdate>='$reg' - INTERVAL 365 DAY " +
    "AND dchdate<='$reg' ORDER BY dchdate DESC, dchtime DESC LIMIT 1")
  if ($last.Count) {
    $lan = [HxDb]::Digits($last[0]['an'])
    $hm = DbQuery ("SELECT r.an AS vn, DATE_FORMAT(i.dchdate,'%Y-%m-%d') AS d, $DRUG_COLS, TRIM(IFNULL(d.name_print,'')) AS name_print " +
      "$DRUG_JOIN JOIN ipt_order_no n ON n.an=r.an AND n.order_no=r.order_no JOIN ipt i ON i.an=r.an " +
      "WHERE r.an='$lan' AND n.order_type='HMe' ORDER BY r.item_no")
    foreach ($r in $hm) { [void]$items.Add(@{ r = $r; dep = 'ยากลับบ้าน (D/C)' }) }
  }
  [ordered]@{ ok = $true; hn = $hn; an = $an; regdate = $reg; chronic = $true; items = @($items | ForEach-Object {
    $q = $_.r; $x = DrugRow $q; $x.vn = $q['vn']; $x.date = $q['d']; $x.dep = $_.dep; $x.namePrint = $q['name_print']; $x }) }
}
# ให้เภสัชเลือกดึงยาเดิมจาก visit อื่นเพิ่มเองในใบ MR (ผู้ใช้ขอ 2026-10-22) — /db/mrmeds เลือกให้แค่นัดล่าสุดของแต่ละคลินิก
#   ทุก visit OPD ที่มียาใน 1 ปีก่อน admit (ไม่นับ visit ที่ admit) + ยากลับบ้าน (HMe) ทุกครั้งที่จำหน่าย — ล่าสุดก่อน
function DbMrVisits($hn, $path) {
  $an = if ($path -match '[?&]an=(\d+)') { $matches[1] } else { '' }
  $ipt = DbQuery "SELECT an, vn, DATE_FORMAT(regdate,'%Y-%m-%d') AS regdate FROM ipt WHERE an='$an' AND hn='$hn' LIMIT 1"
  if (-not $ipt.Count) { throw 'ไม่พบ AN นี้' }
  $reg = $ipt[0]['regdate']; $avn = [HxDb]::Digits($ipt[0]['vn'])
  $op = DbQuery ("SELECT r.vn, DATE_FORMAT(r.vstdate,'%Y-%m-%d') AS d, k.department AS dep, IFNULL(v.pdx,'') AS pdx, " +
    "$DRUG_COLS, TRIM(IFNULL(d.name_print,'')) AS name_print $DRUG_JOIN LEFT JOIN ovst o ON o.vn=r.vn " +
    "LEFT JOIN kskdepartment k ON k.depcode=o.main_dep LEFT JOIN vn_stat v ON v.vn=r.vn " +
    "WHERE r.hn='$hn' AND r.vstdate>='$reg' - INTERVAL 365 DAY AND r.vstdate<='$reg' AND (r.an IS NULL OR r.an='') AND r.vn<>'$avn' " +
    "ORDER BY r.vstdate DESC, r.vn DESC, r.item_no LIMIT 600")
  $hm = DbQuery ("SELECT r.an AS vn, DATE_FORMAT(i.dchdate,'%Y-%m-%d') AS d, 'ยากลับบ้าน (D/C)' AS dep, IFNULL(a.pdx,'') AS pdx, " +
    "$DRUG_COLS, TRIM(IFNULL(d.name_print,'')) AS name_print $DRUG_JOIN JOIN ipt_order_no n ON n.an=r.an AND n.order_no=r.order_no " +
    "JOIN ipt i ON i.an=r.an LEFT JOIN an_stat a ON a.an=r.an " +
    "WHERE i.hn='$hn' AND n.order_type='HMe' AND i.an<>'$an' AND i.dchdate>='$reg' - INTERVAL 365 DAY AND i.dchdate<='$reg' " +
    "ORDER BY i.dchdate DESC, r.item_no")
  $map = [ordered]@{}
  foreach ($r in (@($op) + @($hm) | Where-Object { $_ })) {
    $vn = "$($r['vn'])"
    if (-not $map.Contains($vn)) { $map[$vn] = [ordered]@{ vn = $vn; date = $r['d']; dep = $r['dep']; pdx = $r['pdx']; items = New-Object System.Collections.ArrayList } }
    $x = DrugRow $r; $x.vn = $vn; $x.date = $r['d']; $x.dep = $r['dep']; $x.namePrint = $r['name_print']
    [void]$map[$vn].items.Add($x)
  }
  [ordered]@{ ok = $true; hn = $hn; an = $an; regdate = $reg; visits = @($map.Values | Sort-Object { $_.date } -Descending) }
}
# พจนานุกรมคีย์ยาเดิมจาก รพ.อื่น ในใบ MR: ยาทุกตัวใน drugitems (รวมที่เลิกใช้ — ยานอก รพ. อาจเป็นตัวที่เราไม่มีแล้ว)
# + วิธีใช้ที่เปิดใช้ (status='Y' ~750 จาก 129k แถว) พร้อม code = รหัสย่อที่พิมพ์ใน HOSxP เช่น "11pt (1เม็ด * 1pc)"
function DbMrDict {
  $d = DbQuery "SELECT icode, name, strength, units, dosageform, istatus FROM drugitems WHERE name NOT LIKE 'ยาเดิม%' ORDER BY name"
  $u = DbQuery ("SELECT drugusage, code, TRIM(CONCAT_WS(' ', name1, name2, name3)) AS t FROM drugusage " +
    "WHERE status='Y' AND TRIM(CONCAT_WS('', name1, name2, name3))<>'' ORDER BY LENGTH(drugusage), drugusage")
  [ordered]@{ ok = $true
    drugs = @($d | ForEach-Object { [ordered]@{ icode = $_['icode']; name = $_['name']; strength = $_['strength']; units = $_['units']; form = $_['dosageform']; active = ("$($_['istatus'])" -eq 'Y') } })
    usages = @($u | ForEach-Object { [ordered]@{ id = $_['drugusage']; code = $_['code']; text = $_['t'] } }) }
}
function DbPatient($hn) {
  $rows = DbQuery "SELECT pname, fname, lname, birthday, sex FROM patient WHERE hn='$hn' LIMIT 1"
  if (-not $rows.Count) { return [ordered]@{ ok = $false; hn = $hn; error = 'ไม่พบ HN นี้' } }
  $p = $rows[0]
  [ordered]@{ ok = $true; hn = $hn; pname = $p['pname']; fname = $p['fname']; lname = $p['lname']; birthday = $p['birthday']; sex = $p['sex'] }
}

# Smart Pharmacy (หน้าต่างลอยจ่ายยาของเภสัชกร): ข้อมูลประกอบการตรวจความเหมาะสมของยา visit วันนี้
# อายุ/เพศ, สัญญาณชีพ 4 visit ล่าสุดใน 1 ปี (วันนี้อยู่บนสุดถ้ามี), lab 3 ครั้งล่าสุดต่อรายการใน 400 วัน,
# ประวัติแพ้ยา, วินิจฉัย visit วันนี้ + โรคประจำตัว (ICD10 3 หลักใน 2 ปี), ตารางยาตีกันของ รพ.
$RX_LABS = [ordered]@{ cr = '3036,3003,3118'; egfr = '3189'; k = '3181,3042,3018'; na = '3179,3041'; cl = '3183,3043'; co2 = '3177,3040'; hba1c = '3119'; fbs = '3117'
  ldl = '3191,3008,3122'; tg = '3006,3039,3123'; tc = '3038,3005,3120'; alt = '3055,3015'; ast = '3054'; hb = '1002'; hct = '1003,3127'
  plt = '3062'; uric = '3004,3037'; tsh = '3026'; ft4 = '3164'; uacr = '3138'; pt = '1009'; bun = '3124' }
function DbSmartRx($hn) {
  $p = DbQuery "SELECT sex, TIMESTAMPDIFF(MONTH, birthday, CURDATE()) AS age_m FROM patient WHERE hn='$hn' LIMIT 1"
  $vit = DbQuery ("SELECT DATE_FORMAT(o.vstdate,'%Y-%m-%d') AS d, s.bps, s.bpd, s.pulse, s.bw, s.height, s.pregnancy, s.egfr " +
    "FROM ovst o JOIN opdscreen s ON s.vn=o.vn WHERE o.hn='$hn' AND o.vstdate>=CURDATE()-INTERVAL 1 YEAR AND (s.bps>0 OR s.bw>0) " +
    "ORDER BY o.vstdate DESC, o.vsttime DESC LIMIT 4")
  $codes = ($RX_LABS.Values -join ',')
  $lr = DbQuery ("SELECT DATE_FORMAT(h.order_date,'%Y-%m-%d') AS d, o.lab_items_code AS c, o.lab_order_result AS v FROM lab_head h " +
    "JOIN lab_order o ON o.lab_order_number=h.lab_order_number WHERE h.hn='$hn' AND h.order_date>=CURDATE()-INTERVAL 400 DAY " +
    "AND o.lab_items_code IN ($codes) AND o.lab_order_result IS NOT NULL AND o.lab_order_result<>'' ORDER BY h.order_date DESC, h.order_time DESC LIMIT 400")
  $labs = [ordered]@{}
  foreach ($k in $RX_LABS.Keys) {
    $set = $RX_LABS[$k] -split ','
    $hits = @($lr | Where-Object { $set -contains "$($_['c'])" } | Select-Object -First 3 | ForEach-Object { [ordered]@{ date = $_['d']; value = "$($_['v'])".Trim() } })
    if ($hits.Count) { $labs[$k] = $hits }
  }
  $al = DbQuery ("SELECT agent, symptom, DATE_FORMAT(report_date,'%Y-%m-%d') AS d FROM opd_allergy WHERE hn='$hn' AND IFNULL(allergy_cancel_status,'')<>'Y'")
  $dxT = DbQuery ("SELECT g.icd10, i.name FROM ovstdiag g LEFT JOIN icd101 i ON i.code=g.icd10 WHERE g.hn='$hn' AND g.vstdate=CURDATE() ORDER BY g.diagtype")
  $dxH = DbQuery ("SELECT LEFT(g.icd10,3) AS c, MAX(i.name) AS name, COUNT(*) AS n FROM ovstdiag g LEFT JOIN icd101 i ON i.code=LEFT(g.icd10,3) " +
    "WHERE g.hn='$hn' AND g.vstdate>=CURDATE()-INTERVAL 2 YEAR AND g.icd10 REGEXP '^[A-Z]' GROUP BY LEFT(g.icd10,3) HAVING n>=2 ORDER BY n DESC LIMIT 15")
  $dr = DbQuery "SELECT drugname1, drugname2, severity, not_allow, note FROM drug_interaction WHERE IFNULL(drug_interaction_type,1)=1"
  [ordered]@{ ok = $true; hn = $hn
    sex = $(if ($p.Count) { $p[0]['sex'] }); ageM = $(if ($p.Count) { $p[0]['age_m'] })
    vitals = @($vit | ForEach-Object { [ordered]@{ date = $_['d']; bps = $_['bps']; bpd = $_['bpd']; pulse = $_['pulse']; bw = $_['bw']
      height = $_['height']; pregnancy = $_['pregnancy']; egfr = $_['egfr'] } })
    labs = $labs
    allergy = @($al | ForEach-Object { [ordered]@{ hn = $hn; agent = $_['agent']; symptom = $_['symptom']; date = $_['d'] } })
    dxToday = @($dxT | ForEach-Object { [ordered]@{ code = $_['icd10']; name = $_['name'] } })
    dxHistory = @($dxH | ForEach-Object { [ordered]@{ code = $_['c']; name = $_['name']; n = $_['n'] } })
    ddi = @($dr | ForEach-Object { [ordered]@{ a = $_['drugname1']; b = $_['drugname2']; severity = $_['severity']; notAllow = $_['not_allow']; note = $_['note'] } }) }
}

# วันนัดจาก DB แทน OCR: อ่านเมื่อเปลี่ยนคนไข้ แล้วทุก 20 วินาที (เผื่อเพิ่งลงนัดใน HOSxP) — DB ใช้ไม่ได้ค่อยกลับไป OCR
function ApptFromDb($hn) {
  if (-not $db -or -not $hn) { return $false }
  if ($apptDbAt.ContainsKey($hn) -and ((Get-Date) - $apptDbAt[$hn]).TotalSeconds -lt 20) { return $true }
  try {
    $a = DbAppts $hn
    $apptDbAt[$hn] = Get-Date
    $d = if ($a.Count) { ($a | ForEach-Object { $_.days } | Measure-Object -Maximum).Maximum } else { $null }
    $state.apptDays = $d; $script:apptByHn[$hn] = $d
    return $true
  } catch { return $false }
}

# ── Mac (อ่านหน้าจอไม่ได้): คนไข้ที่เครื่องนี้เปิดใน Patient EMR ล่าสุด จากฐานข้อมูล ─────────────────────────
# HOSxP เขียน patient_emr_log (เวลา ผู้ใช้ ชื่อเครื่อง HN) ทุกครั้งที่เปิด Patient EMR — ชื่อเครื่องของ HOSxP ใน Wine
# (เช่น "MAC") หาจาก onlineuser ที่ login ล่าสุดจาก IP ของเครื่องนี้ หรือกำหนดเองใน hosxp-computer.txt
# เปิด EMR คนใหม่ = เปลี่ยนคนไข้ ปิด EMR แล้วคงคนล่าสุดไว้ (เหมือนบน Windows) — ข้ามวันแล้วล้าง
$macPc = ''; $macPcAt = [DateTime]::MinValue; $macEmrId = 0; $nextMacPoll = [DateTime]::MinValue
function LocalIps {
  @([System.Net.NetworkInformation.NetworkInterface]::GetAllNetworkInterfaces() |
    Where-Object { $_.OperationalStatus -eq 'Up' } |
    ForEach-Object { $_.GetIPProperties().UnicastAddresses } |
    Where-Object { $_.Address.AddressFamily -eq 'InterNetwork' -and -not [System.Net.IPAddress]::IsLoopback($_.Address) } |
    ForEach-Object { $_.Address.ToString() })
}
function MacComputer {
  $f = Join-Path $PSScriptRoot 'hosxp-computer.txt'
  if (Test-Path $f) { return (Get-Content $f -Raw -Encoding UTF8).Trim() }
  if ($script:macPc -and (Get-Date) -lt $script:macPcAt) { return $script:macPc }
  $ips = @(LocalIps | Where-Object { $_ -match '^[\d.]+$' })
  $script:macPcAt = (Get-Date).AddSeconds(60)
  if (-not $ips.Count) { return $script:macPc }
  $r = DbQuery ("SELECT computername FROM onlineuser WHERE ip_address IN ('" + ($ips -join "','") + "') " +
    "AND computername<>'' ORDER BY ksklogintime DESC LIMIT 1")
  if ($r.Count) { $script:macPc = [string]$r[0]['computername'] }
  $script:macPc
}
function MacUpdateState {
  $state.ok = [bool]$db
  if (-not $db) { return }
  $pc = MacComputer
  $state.pc = $pc
  if (-not $pc) { return }
  # ตารางไม่มี index ตามเครื่อง/เวลา — ไล่จาก id ล่าสุดย้อนไปไม่เกิน 20000 แถว (ประมาณ 1-2 สัปดาห์)
  if (-not $script:macEmrId) { $m = DbQuery 'SELECT MAX(patient_emr_log_id) AS m FROM patient_emr_log'; $script:macEmrId = [int]$m[0]['m'] - 20000 }
  $pcSql = $pc -replace "[^\w\-. ]", ''
  $r = DbQuery ("SELECT l.patient_emr_log_id AS id, l.hn, DATE_FORMAT(l.access_datetime,'%Y-%m-%d') AS d, " +
    "TRIM(CONCAT(IFNULL(p.pname,''), IFNULL(p.fname,''), ' ', IFNULL(p.lname,''))) AS name " +
    "FROM patient_emr_log l LEFT JOIN patient p ON p.hn=l.hn " +
    "WHERE l.patient_emr_log_id > $($script:macEmrId) AND l.computer='$pcSql' ORDER BY l.patient_emr_log_id DESC LIMIT 1")
  $today = (Get-Date).ToString('yyyy-MM-dd')
  if ($r.Count) {
    $script:macEmrId = [int]$r[0]['id']
    $hn = [HxDb]::Digits($r[0]['hn'])
    if ($r[0]['d'] -eq $today -and $hn) {
      $state.emrHn = $hn; $state.emrName = [string]$r[0]['name']
      $state.hn = $hn; $state.name = $state.emrName; $state.emrDate = $today
    }
  }
  if ($state.emrDate -and $state.emrDate -ne $today) { $state.emrHn = ''; $state.emrName = ''; $state.hn = ''; $state.name = ''; $state.emrDate = '' }
  # หน้าต่างลอยจ่ายยา/ยาคงเหลือ: ใบสั่งยาและวันนัดมาจากฐานข้อมูลอยู่แล้ว ถือว่าอยู่หน้าจ่ายยาตลอด
  $state.active = [bool]$state.hn
  if ($state.hn) { [void](ApptFromDb $state.hn) }
}

function DbHaCases {
  # รายเคสตัวชี้วัด HA (แพ้ยาซ้ำ / RAS 2 ชนิด / ยาห้ามใช้ในหญิงตั้งครรภ์) ที่ pharmacy_ha_sync.py เขียนไว้ในเครื่องนี้
  $f = if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'HOSxPBridge\ha-cases.json' } else { Join-Path $PSScriptRoot 'ha-cases.json' }
  if (-not (Test-Path $f)) { return '{"ok":false,"error":"เครื่องนี้ไม่ได้รัน pharmacy_ha_sync.py"}' }
  '{"ok":true,"data":' + [System.IO.File]::ReadAllText($f, [System.Text.Encoding]::UTF8) + '}'
}

function DbEndpoint($path) {
  if ($path -like '/db/hacases*') { return DbHaCases }
  # endpoint ที่ไม่ใช้ HN
  if ($path -like '/db/denom*' -or $path -like '/db/adr*' -or $path -match '^/db/me(\?|$)' -or $path -like '/db/nightmeds*' -or $path -like '/db/dmroster*' -or $path -like '/db/dmscreen*' -or $path -like '/db/rxqueue*' -or $path -like '/db/ipdlist*' -or $path -like '/db/hme*' -or $path -like '/db/mrdict*') {
    try { $res = if ($path -like '/db/denom*') { DbDenom } elseif ($path -like '/db/adr*') { DbAdr $path }
      elseif ($path -match '^/db/me(\?|$)') { DbMe $path }
      elseif ($path -like '/db/nightmeds*') { DbNightMeds $path }
      elseif ($path -like '/db/dmroster*') { DbDmRoster } elseif ($path -like '/db/rxqueue*') { DbRxQueue } elseif ($path -like '/db/ipdlist*') { DbIpdList } elseif ($path -like '/db/hme*') { DbHme } elseif ($path -like '/db/mrdict*') { DbMrDict } else { DbDmScreen } }
    catch { $res = [ordered]@{ ok = $false; error = "$_" } }
    return [HxDb]::Json($res)
  }
  $hn = $null
  if ($path -match '[?&]hn=([^&]*)') { $hn = [HxDb]::Digits([Uri]::UnescapeDataString($Matches[1])) }
  try {
    if (-not $hn) { throw 'ต้องระบุ hn เป็นตัวเลข' }
    $res = if ($path -like '/db/order*') { DbOrder $hn } elseif ($path -like '/db/visits*') { DbVisits $hn }
      elseif ($path -like '/db/meds*') { DbMeds $hn }
      elseif ($path -like '/db/dmvisits*') { DbDmVisits $hn $path }
      elseif ($path -like '/db/rxsticker*') { DbRxSticker $hn }
      elseif ($path -like '/db/smartrx*') { DbSmartRx $hn }
      elseif ($path -like '/db/errx*') { DbErRx $hn $path }
      elseif ($path -like '/db/mrmeds*') { DbMrMeds $hn $path }
      elseif ($path -like '/db/mrvisits*') { DbMrVisits $hn $path }
      elseif ($path -like '/db/patient*') { DbPatient $hn } else { throw 'ไม่รู้จัก endpoint' }
  } catch { $res = [ordered]@{ ok = $false; error = "$_" } }
  return [HxDb]::Json($res)
}

function FieldRightOf($frame, $labelText) {
  $label = $frame.FindAll($TS::Descendants, (ClassCond 'TcxLabel')) | Where-Object { $_.Current.Name -eq $labelText } | Select-Object -First 1
  if (-not $label) { return $null }
  $lr = $label.Current.BoundingRectangle
  $frame.FindAll($TS::Descendants, (ClassCond 'TcxDBTextEdit')) |
    Where-Object { $r = $_.Current.BoundingRectangle; [Math]::Abs($r.Y - $lr.Y) -lt 12 -and $r.X -gt $lr.X } |
    Sort-Object { $_.Current.BoundingRectangle.X } | Select-Object -First 1
}

# หน้าจอ จพ.เภสัช (DoctorWorkBenchQueueForm → บันทึกใบสั่งยา) ไม่ใช่หน้าจ่ายยาของเภสัช: ไม่มีป้าย HN/ชื่อ
#   HN   = TcxDBTextEdit ใน TPatientInformationType2Frame (ซ่อนอยู่นอกจอ แต่ UI Automation อ่านค่าได้)
#   ชื่อ = ชื่อของ TcxTabSheet ที่ครอบหน้านั้น เช่น "นายสายันต์ ทิพย์สว่าง [9]" (ตัด [คิว] ออก)
# เปิดได้หลายแท็บคนไข้ จึงเลือกหน้าที่ตารางใบสั่งยาอยู่บนจอจริง และค้นใหม่ทุก ~1.5 วินาที
function FindDispenseScreen2($main) {
  $best = $null
  foreach ($f in $main.FindAll($TS::Descendants, (ClassCond 'THOSxPDispensingEntryFrame'))) {
    $order = $f.FindFirst($TS::Descendants, (ClassCond 'THOSxPMedicationOrderFrame'))
    $grid = if ($order) { $order.FindFirst($TS::Descendants, (ClassCond 'TcxGridSite')) } else { $null }
    $info = $f.FindFirst($TS::Descendants, (ClassCond 'TPatientInformationType2Frame'))
    $hn = if ($info) { FieldRightOf $info 'HN' } else { $null }   # ใกล้ป้าย HN ที่สุด (ในกรอบมีเบอร์โทร/เลขบัตรด้วย จะหยิบผิดถ้าดูแค่ตัวเลข)
    if (-not $hn -or $hn.Current.Name.Trim() -notmatch '^\d{5,10}$') { continue }
    $cand = @{ hn = $hn; grid = $grid; frame = $f }
    if (-not $best) { $best = $cand }
    if ($grid -and (ElShowing $grid)) { $best = $cand; break }
  }
  if (-not $best) { return $false }
  $cache.hnEdit = $best.hn; $cache.grid = $best.grid; $cache.layout2 = $true
  $cache.apptLabel = $best.frame.FindAll($TS::Descendants, (ClassCond 'TcxLabel')) | Where-Object { $_.Current.Name -eq 'นัดครั้งหน้า' } | Select-Object -First 1
  $sheet = [System.Windows.Automation.TreeWalker]::RawViewWalker.GetParent($best.frame)
  $cache.nameEdit = if ($sheet -and $sheet.Current.ClassName -eq 'TcxTabSheet') { $sheet } else { $null }
  return $true
}

function FindDispenseScreen {
  $cache.hnEdit = $null; $cache.nameEdit = $null; $cache.apptList = $null; $cache.grid = $null; $cache.layout2 = $false; $cache.apptLabel = $null
  $proc = Get-Process HOSxPXE4 -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $proc) { return }
  $main = $AE::RootElement.FindFirst($TS::Children, (New-Object System.Windows.Automation.PropertyCondition($AE::ProcessIdProperty, [int]$proc.Id)))
  if (-not $main) { return }
  $frame = $main.FindFirst($TS::Descendants, (ClassCond 'THOSxPDiepensingDispenseEntryFrame'))
  if (-not $frame) { [void](FindDispenseScreen2 $main); return }
  $cache.hnEdit = FieldRightOf $frame 'HN'
  $cache.nameEdit = FieldRightOf $frame 'ชื่อ'
  $cache.apptList = $frame.FindFirst($TS::Descendants, (ClassCond 'THTMListBox'))
  $order = $frame.FindFirst($TS::Descendants, (ClassCond 'THOSxPMedicationOrderFrame'))
  if ($order) { $cache.grid = $order.FindFirst($TS::Descendants, (ClassCond 'TcxGridSite')) }
}

function HosxpMain {
  $proc = Get-Process HOSxPXE4 -ErrorAction SilentlyContinue | Select-Object -First 1
  if (-not $proc) { return $null }
  $AE::RootElement.FindFirst($TS::Children, (New-Object System.Windows.Automation.PropertyCondition($AE::ProcessIdProperty, [int]$proc.Id)))
}

# หาหน้า Patient EMR ทุกหน้าที่เปิดอยู่ พร้อมช่อง HN/ชื่อ ของแต่ละหน้า (ค้นทั้งต้นไม้ช้า ~0.3 วินาที ทำทุก 3 วินาที)
function ScanEmr {
  $list = @()
  $main = HosxpMain
  if ($main) {
    foreach ($emr in $main.FindAll($TS::Descendants, (ClassCond 'TPtEMRForm'))) {
      $edits = @($emr.FindAll($TS::Descendants, (ClassCond 'TcxTextEdit')))
      $hn = $edits | Where-Object { $_.Current.Name.Trim() -match '^\d{5,10}$' } |
        Sort-Object { $_.Current.BoundingRectangle.Y }, { $_.Current.BoundingRectangle.X } | Select-Object -First 1
      if (-not $hn) { continue }
      $hr = $hn.Current.BoundingRectangle
      $name = $edits | Where-Object { $r = $_.Current.BoundingRectangle; [Math]::Abs($r.Y - $hr.Y) -lt 6 -and $r.X -gt $hr.X } |
        Sort-Object { $_.Current.BoundingRectangle.X } | Select-Object -First 1
      # ตารางยาของ visit ที่เลือก (แท็บ "รายการยา" → TcxGridSite) มีเฉพาะตอนแท็บนั้นเปิดอยู่
      $sheet = $emr.FindAll($TS::Descendants, (ClassCond 'TcxTabSheet')) | Where-Object { $_.Current.Name -eq 'รายการยา' } | Select-Object -First 1
      $grid = if ($sheet) { $sheet.FindFirst($TS::Descendants, (ClassCond 'TcxGridSite')) } else { $null }
      $list += , @{ form = $emr; hn = $hn; name = $name; grid = $grid }
    }
  }
  $cache.emr = $list
  if (-not $list.Count) { $state.emrHn = ''; $state.emrName = '' }
}

# เลือกหน้า EMR ที่อยู่บนสุด (กลางหน้านั้นไม่ถูกหน้าต่างอื่นบัง) ถ้าไม่มี ใช้หน้าที่ยังเห็นช่อง HN
function ReadEmr {
  $best = $null
  foreach ($e in $cache.emr) {
    try {
      $fr = $e.form.Current.BoundingRectangle
      if ([HxWin]::IsShowing([int]($fr.X + $fr.Width / 2), [int]($fr.Y + $fr.Height / 2), [IntPtr]$e.form.Current.NativeWindowHandle)) { $best = $e; break }
      if (-not $best -and (ElShowing $e.hn)) { $best = $e }
    } catch {}
  }
  if (-not $best) { return }
  $hn = $best.hn.Current.Name.Trim()
  if ($hn -notmatch '^\d{5,10}$') { return }
  $state.emrHn = $hn
  $state.emrName = if ($best.name) { $best.name.Current.Name.Trim() } else { '' }
  if ((Get-Date) -ge $script:nextEmrGrid) {
    $script:nextEmrGrid = (Get-Date).AddSeconds(2)
    CaptureEmrGrid $best.grid $hn $best.form
  }
}

# จับภาพตารางยาของ visit ที่เภสัชเลือกใน Patient EMR ให้หน้าต่างลอยบันทึกคลินิก OCR เอาชื่อยาไปใส่ช่องยาคงเหลือ
# ภาพเปลี่ยน (เลือก visit อื่น) → emrGridVer เพิ่ม; แฮชรวม HN ไว้ด้วย คนละคนที่บังเอิญภาพเหมือนกันจะได้ไม่ถือว่าซ้ำ
# visit ที่เปิดอยู่ใน Patient EMR (แท็บ Screen & ตรวจรักษา) — ช่องไม่มีป้ายกำกับ อ่านตามรูปแบบ/ตำแหน่ง:
#   วันที่มา = ช่องที่เป็น "20 พฤษภาคม 2569" (บนสุด), เวลา = ช่อง "07:48:22" แถวเดียวกัน
#   ห้องตรวจ = ช่องขวาสุดของแถวถัดลงมา (แถว สิทธิการรักษา / เลขที่ / ห้องตรวจ)
# คืน "วันที่|เวลา|ห้องตรวจ" หรือ '' ถ้าหาไม่เจอ
function ReadEmrVisit($form) {
  $sheet = $form.FindAll($TS::Descendants, (ClassCond 'TcxTabSheet')) | Where-Object { $_.Current.Name -like 'Screen*' } | Select-Object -First 1
  $root = if ($sheet) { $sheet } else { $form }
  $edits = @($root.FindAll($TS::Descendants, (ClassCond 'TcxTextEdit')) | ForEach-Object { @{ t = $_.Current.Name.Trim(); r = $_.Current.BoundingRectangle } })
  $date = $edits | Where-Object { $_.t -match '^\d{1,2}\s+\S+\s+\d{4}$' } | Sort-Object { $_.r.Y } | Select-Object -First 1
  if (-not $date) { return '' }
  $dr = $date.r
  $time = $edits | Where-Object { [Math]::Abs($_.r.Y - $dr.Y) -lt 6 -and $_.t -match '^\d{1,2}:\d{2}' } | Select-Object -First 1
  $room = $edits | Where-Object { $_.r.Y -gt $dr.Y + 10 -and $_.r.Y -lt $dr.Y + 40 -and $_.r.X -gt $dr.X + 300 } |
    Sort-Object { $_.r.Y }, { -$_.r.X } | Select-Object -First 1
  return ($date.t + '|' + $(if ($time) { $time.t } else { '' }) + '|' + $(if ($room) { $room.t } else { '' }))
}

function CaptureEmrGrid($grid, $hn, $form) {
  if (-not $grid -or -not (ElShowing $grid)) { return }
  $r = $grid.Current.BoundingRectangle
  if ($r.Width -le 0 -or $r.Height -le 0) { return }
  $vis = VisibleWidth $r $grid
  if ($vis -lt 300) { return }
  $bmp = CaptureScreen ([int]$r.X) ([int]$r.Y) $vis ([int]$r.Height)
  $ms = New-Object System.IO.MemoryStream
  $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png); $bmp.Dispose()
  $bytes = $ms.ToArray(); $ms.Dispose()
  $visit = ''
  try { $visit = ReadEmrVisit $form } catch {}
  # รวม visit ไว้ในแฮช — เปิด visit อื่นที่ยาเหมือนกันทุกตัว หน้าเว็บก็ต้องรู้ว่าเป็นคนละ visit
  $raw = $hn + '|' + $visit + '|' + [BitConverter]::ToString($md5.ComputeHash($bytes))
  if ($raw -ne $script:emrGridRaw) {
    $script:emrGridRaw = $raw; $script:emrGridPng = $bytes; $state.emrGridVer++; $state.emrVisit = $visit
    $state.emrGridHash = ([BitConverter]::ToString($md5.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($raw))) -replace '-', '').Substring(0, 16)
  }
}

# ความกว้างจากขอบซ้ายของ control ที่มองเห็นจริง (ไม่ถูกหน้าต่างอื่นบัง) — สุ่มตรวจเป็นจุดๆ
function VisibleWidth($r, $el) {
  $hwnd = [IntPtr]$el.Current.NativeWindowHandle
  $ys = @([int]($r.Y + 4), [int]($r.Y + $r.Height / 2), [int]($r.Y + $r.Height - 4))
  for ($x = [int]$r.X + 4; $x -lt $r.X + $r.Width; $x += 30) {
    foreach ($y in $ys) { if (-not [HxWin]::IsShowing($x, $y, $hwnd)) { return [int]($x - $r.X - 4) } }
  }
  return [int]$r.Width
}

# control นี้อยู่บนจอให้เห็นจริงไหม (ตรวจจุดใกล้มุมซ้ายบน ซึ่งหน้าต่างลอยที่วางทางขวาไม่บัง)
function ElShowing($el) {
  if (-not $el) { return $false }
  $r = $el.Current.BoundingRectangle
  if ($r.IsEmpty -or $r.Width -le 0 -or $el.Current.IsOffscreen) { return $false }
  return [HxWin]::IsShowing([int]($r.X + 8), [int]($r.Y + [Math]::Min(8, $r.Height / 2)), [IntPtr]$el.Current.NativeWindowHandle)
}

function CaptureScreen($x, $y, $w, $h) {
  $bmp = New-Object System.Drawing.Bitmap $w, $h
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.CopyFromScreen($x, $y, 0, 0, $bmp.Size); $g.Dispose()
  return $bmp
}

function ReadApptDays {
  $list = $cache.apptList
  if (-not $list -or -not $ocr) { return $null }
  $r = $list.Current.BoundingRectangle
  # คนไข้บางคนมีหลายนัด (เช่น นัด LAB 7 วัน + นัดพบแพทย์ 126 วัน) อ่านทุกบรรทัดในกล่อง แล้วใช้วันนัดที่ไกลที่สุด
  $w = [int]$r.Width; $h = [int][Math]::Min($r.Height, 150)
  if ($w -le 0 -or $h -le 0) { return $null }
  $vis = VisibleWidth (New-Object System.Windows.Rect $r.X, $r.Y, $w, $h) $list
  if ($vis -lt 250) { $state.covered = $true; return $null }   # "1.[119 วัน] 22 ..." อยู่ต้นบรรทัด เห็นแค่ช่วงแรกก็พอ
  return OcrDays ([int]$r.X) ([int]$r.Y) $vis $h
}

# หน้า "ข้อมูลทั่วไป" ของ จพ.: วันนัดเป็นข้อความที่วาดเอง "นัดครั้งหน้า[126 วัน] 4 กุมภาพันธ์ ..." อยู่ถัดจากป้าย "นัดครั้งหน้า"
# อ่านผ่าน API ไม่ได้ จึง OCR แถบทางขวาของป้ายเฉพาะตอนป้ายนั้นอยู่บนจอ (ถ้าถูกบัง OCR จะไม่เจอเลข ก็คงค่าเดิมไว้)
# คนไข้ที่มีหลายนัด มีบรรทัดที่สองใต้ป้าย "วันนัดอื่นๆ [119 วัน]" (ขึ้นต้นตรงแนวป้าย) — อ่านแยกอีกแถบ แล้วใช้นัดที่ไกลที่สุด
# (อ่านรวมสองบรรทัดในภาพเดียวไม่ได้ OCR ทิ้ง "[8 วัน]" สีแดงตัวเล็กของบรรทัดแรกไป)
function ReadApptCard {
  $lb = $cache.apptLabel
  if (-not $lb -or -not (ElShowing $lb)) { return $null }
  $r = $lb.Current.BoundingRectangle
  $x = [int]($r.X + $r.Width + 2); $y = [int]($r.Y - 2); $h = [int]($r.Height + 4)
  $first = OcrDays $x $y 380 $h $true
  $other = $null
  try { $other = OcrDays ([int]$r.X) ([int]($r.Y + $r.Height - 6)) 300 ([int]($r.Height + 4)) } catch {}
  if ($other -ne $null -and ($first -eq $null -or $other -gt $first)) { return $other }
  return $first
}

# OCR ภาษาอังกฤษของ Windows อ่านแถบข้อความ เอาตัวเลขในวงเล็บ [N วัน]
function OcrDays($x, $y, $vis, $h, [bool]$loose = $false) {
  $bmp = CaptureScreen $x $y $vis $h
  # ขยาย 2 เท่า OCR อ่านตัวเลขเล็กๆ ได้แม่นขึ้น
  $big = New-Object System.Drawing.Bitmap ($vis * 2), ($h * 2)
  $g2 = [System.Drawing.Graphics]::FromImage($big)
  $g2.InterpolationMode = [System.Drawing.Drawing2D.InterpolationMode]::HighQualityBicubic
  $g2.DrawImage($bmp, 0, 0, $vis * 2, $h * 2); $g2.Dispose(); $bmp.Dispose()
  $ms = New-Object System.IO.MemoryStream
  $big.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png); $big.Dispose()
  $ms.Position = 0
  $ras = [System.IO.WindowsRuntimeStreamExtensions]::AsRandomAccessStream($ms)
  $dec = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($ras)) ([Windows.Graphics.Imaging.BitmapDecoder])
  $sb = Await ($dec.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
  $res = Await ($ocr.RecognizeAsync($sb)) ([Windows.Media.Ocr.OcrResult])
  $ms.Dispose()
  if (-not $loose) {
    # กล่อง "ข้อมูลการนัดหมาย": ทุกบรรทัดขึ้นต้น "N.[X วัน]" เอา X ที่มากที่สุด (นัดไกลสุด)
    $days = @($res.Lines | ForEach-Object { if ($_.Text -match '\[\s*(\d{1,4})') { [int]$Matches[1] } })
    if ($days.Count) { return ($days | Measure-Object -Maximum).Maximum }
    return $null
  }
  foreach ($line in $res.Lines) {
    if ($line.Text -match '\[\s*(\d{1,4})') { return [int]$Matches[1] }
  }
  # OCR บางครั้งทิ้ง "[" หรืออ่านเป็น "1"/"I" เช่น "126 วัน" → "126" หรือ "1126" — ใช้เลขชุดแรกต้นบรรทัด
  # วันนัดเกิน 999 วันไม่มีจริง ถ้าได้ 4 หลักแปลว่าวงเล็บถูกอ่านเป็นเลข 1 ตัดหลักหน้าออก
  if (-not $loose) { return $null }   # กล่อง "ข้อมูลการนัดหมาย" ขึ้นต้นด้วยลำดับ "1." เลขชุดแรกจึงไม่ใช่วัน ใช้เฉพาะแถบนัดครั้งหน้า
  foreach ($line in $res.Lines) {
    if ($line.Text -match '^\W*(\d{1,4})\b') {
      $n = [int]$Matches[1]
      if ($n -ge 1000) { $n = $n % 1000 }
      if ($n -gt 0) { return $n }
    }
  }
  return $null
}

# จับภาพตารางใบสั่งยา เปลี่ยนเลข gridVer เมื่อภาพเปลี่ยน หน้าเว็บจะได้ OCR ใหม่เฉพาะตอนจำเป็น
function CaptureGrid {
  $grid = $cache.grid
  if (-not $grid) { return }
  $r = $grid.Current.BoundingRectangle
  if ($r.Width -le 0 -or $r.Height -le 0) { return }
  $vis = VisibleWidth $r $grid
  $state.gridCut = $vis -lt $r.Width
  if ($vis -lt 300) { $state.covered = $true; return }
  $bmp = CaptureScreen ([int]$r.X) ([int]$r.Y) $vis ([int]$r.Height)
  $ms = New-Object System.IO.MemoryStream
  $bmp.Save($ms, [System.Drawing.Imaging.ImageFormat]::Png); $bmp.Dispose()
  $bytes = $ms.ToArray(); $ms.Dispose()
  $hash = [BitConverter]::ToString($md5.ComputeHash($bytes))
  # gridHash ให้หน้าเว็บจำผล OCR ตามภาพ (HN เดิม+ภาพเดิม = ไม่ต้อง OCR ซ้ำ ตอนสลับหน้าไปมา)
  if ($hash -ne $script:gridHash) { $script:gridHash = $hash; $script:gridPng = $bytes; $state.gridVer++; $state.gridHash = ($hash -replace '-', '').Substring(0, 16) }
}

function UpdateState {
  $hn = ''; $name = ''
  try {
    # หน้าจอ จพ. เปิดหลายแท็บได้ ค้นใหม่บ่อยเพื่อตามแท็บที่อยู่บนจอ
    if (-not $cache.hnEdit -or ($cache.layout2 -and (Get-Date) -ge $script:nextFind)) {
      FindDispenseScreen; $script:nextFind = (Get-Date).AddMilliseconds(1500)
    }
    if ($cache.hnEdit) {
      $hn = $cache.hnEdit.Current.Name.Trim()
      if ($cache.nameEdit) { $name = ($cache.nameEdit.Current.Name.Trim() -replace '\s*\[\d+\]\s*$', '') }
    }
  } catch {
    # หน้าจ่ายยาถูกปิด/สร้างใหม่ — element เดิมใช้ไม่ได้แล้ว ค้นหาใหม่
    FindDispenseScreen
    if ($cache.hnEdit) { try { $hn = $cache.hnEdit.Current.Name.Trim() } catch {} }
  }

  if ($hn -ne $script:lastHn) {
    # จำวันนัดที่เคยอ่านได้ของ HN นี้ไว้ (จพ. ดูวันนัดที่หน้าหนึ่งแล้วสลับไปหน้าสั่งยา ซึ่งอ่านวันนัดไม่ได้)
    $script:lastHn = $hn; $state.apptDays = if ($hn -and $script:apptByHn.ContainsKey($hn)) { $script:apptByHn[$hn] } else { $null }
    $script:gridPng = $null; $script:gridHash = ''; $state.gridHash = ''; $state.gridVer++
    $script:nextAppt = [DateTime]::MinValue; $script:nextGrid = [DateTime]::MinValue
  }
  $active = $false
  # หน้าจอ จพ. ช่อง HN ซ่อนนอกจอเสมอ ใช้ตารางใบสั่งยาที่เห็นบนจอเป็นตัวบอกว่าอยู่หน้าบันทึกใบสั่งยา
  if ($hn) { try { $active = if ($cache.layout2) { ElShowing $cache.grid } else { (ElShowing $cache.hnEdit) -and (ElShowing $cache.grid) } } catch {} }
  $state.active = $active
  # หน้า "ข้อมูลทั่วไป" ของ จพ. (กรอบข้อมูลผู้ป่วยอยู่บนจอ ตารางยาอาจไม่เต็ม) อ่านวันนัดแล้วจำตาม HN ไว้ใช้ตอนสลับไปหน้าสั่งยา
  $apptDb = $false
  if ($hn) { $apptDb = ApptFromDb $hn }
  if ($hn -and -not $apptDb -and $cache.layout2 -and (Get-Date) -ge $script:nextCard) {
    $script:nextCard = (Get-Date).AddSeconds(2)
    try { $d = ReadApptCard; if ($d -ne $null) { $state.apptDays = $d; $script:apptByHn[$hn] = $d } } catch {}
  }
  if ($active) {
    $state.covered = $false
    # วันนัดอ่านซ้ำทุก 5 วินาที ตารางยาทุก 2 วินาที เผื่อข้อมูลโหลดขึ้นมาทีหลัง หรือเพิ่งเลื่อนหน้าต่างที่บังออก
    if (-not $apptDb -and (Get-Date) -ge $script:nextAppt) {
      try { $d = ReadApptDays; if ($d -ne $null) { $state.apptDays = $d; $script:apptByHn[$hn] = $d } } catch {}
      $script:nextAppt = (Get-Date).AddSeconds(5)
    }
    if ((Get-Date) -ge $script:nextGrid) {
      try { CaptureGrid } catch {}
      $script:nextGrid = (Get-Date).AddSeconds(2)
    }
  }
  if ((Get-Date) -ge $script:nextEmrScan) {
    try { ScanEmr } catch { $cache.emr = @() }
    $script:nextEmrScan = (Get-Date).AddSeconds(3)
  }
  try { ReadEmr } catch {}
  $state.ok = [bool]$cache.hnEdit
  $state.hn = $hn; $state.name = $name
  $state.ts = [DateTimeOffset]::Now.ToUnixTimeMilliseconds()
}

# ── อัปเดตตัวเองจากเว็บ (หน้าเว็บสั่งอัตโนมัติเมื่อพบว่า bridge เครื่องนี้เป็นรุ่นเก่า) ─────────────────────────
# รายการไฟล์อยู่ใน update.json บนเว็บ (src = path ใน hosxp-bridge/, dst = ชื่อไฟล์ในเครื่อง, os = win/mac/ไม่ระบุ = ทุกเครื่อง)
# เวอร์ชัน = SHA-256 ของไฟล์ทั้งชุด (ตัด BOM, ขึ้นบรรทัดแบบ LF) — ไม่ต้องเปลี่ยนเลขเวอร์ชันเอง แก้ไฟล์แล้ว push ก็พอ
# db.json / hme-station.txt / autostart-days.txt ไม่อยู่ในรายการ จึงไม่ถูกแตะ — สำรองไฟล์เดิมไว้ใน backup\ ก่อนเขียนทับทุกครั้ง
$DEFAULT_FILES = @(
  @{ src = 'hosxp-bridge.ps1' }, @{ src = 'hxdb.cs' }, @{ src = 'hme-printer.ps1'; os = 'win' },
  @{ src = 'start-bridge.bat'; os = 'win' }, @{ src = 'stop-bridge.bat'; os = 'win' },
  @{ src = 'HME-AutoPrint.bat'; os = 'win' }, @{ src = 'HME-AutoPrint-setup.bat'; os = 'win' },
  @{ src = 'installer/uninstall.ps1'; dst = 'uninstall.ps1'; os = 'win' })
function UpdList($files) {
  @($files | Where-Object { -not $_.os -or $_.os -eq $OS } | ForEach-Object {
    @{ src = [string]$_.src; dst = $(if ($_.dst) { [string]$_.dst } else { Split-Path ([string]$_.src) -Leaf }) } })
}
function NormText([byte[]]$b) {
  $t = [System.Text.Encoding]::UTF8.GetString($b)
  if ($t.Length -and $t[0] -eq [char]0xFEFF) { $t = $t.Substring(1) }
  $t -replace "`r`n", "`n"
}
function VersionOf($items) {
  $sb = New-Object System.Text.StringBuilder
  foreach ($i in ($items | Sort-Object { $_.dst })) { [void]$sb.Append($i.dst + "`n" + $i.text + "`n") }
  $h = [System.Security.Cryptography.SHA256]::Create().ComputeHash([System.Text.Encoding]::UTF8.GetBytes($sb.ToString()))
  ([BitConverter]::ToString($h) -replace '-', '').Substring(0, 10).ToLower()
}
function LocalItems($list) {
  @($list | ForEach-Object { $p = Join-Path $PSScriptRoot $_.dst
    @{ dst = $_.dst; text = $(if (Test-Path $p) { NormText ([IO.File]::ReadAllBytes($p)) } else { '' }) } })
}
function LocalList {
  $f = Join-Path $PSScriptRoot 'update.json'
  try { if (Test-Path $f) { return UpdList ((Get-Content $f -Raw -Encoding UTF8 | ConvertFrom-Json).files) } } catch {}
  UpdList $DEFAULT_FILES
}
function Fetch($url) {
  [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12
  $rq = [Net.HttpWebRequest]::Create($url + '?t=' + [DateTime]::UtcNow.Ticks)   # ข้าม cache ของ GitHub Pages
  $rq.Timeout = 10000; $rq.ReadWriteTimeout = 10000
  $rs = $rq.GetResponse()
  try { $ms = New-Object System.IO.MemoryStream; $rs.GetResponseStream().CopyTo($ms); return , $ms.ToArray() } finally { $rs.Close() }
}
# ไฟล์ชุดล่าสุดบนเว็บ — จำผลไว้ 10 นาที (ล้มเหลวจำ 2 นาที) bridge ทำงานวนรอบเดียว จะได้ไม่ค้างรอเน็ตบ่อย
$remote = $null; $remoteAt = [DateTime]::MinValue
function RemoteSet([bool]$fresh) {
  if (-not $fresh -and $script:remote -and (Get-Date) -lt $script:remoteAt) { return $script:remote }
  try {
    $man = NormText (Fetch ($UPDATE_BASE + 'update.json'))
    $list = UpdList ($man | ConvertFrom-Json).files
    $items = @($list | ForEach-Object { @{ src = $_.src; dst = $_.dst; text = (NormText (Fetch ($UPDATE_BASE + $_.src))) } })
    $script:remote = @{ ok = $true; list = $list; items = $items; manifest = $man; version = (VersionOf $items) }
    $script:remoteAt = (Get-Date).AddMinutes(10)
  } catch {
    $script:remote = @{ ok = $false; error = "โหลดไฟล์จากเว็บไม่ได้: $($_.Exception.Message)" }
    $script:remoteAt = (Get-Date).AddMinutes(2)
  }
  $script:remote
}
# เครื่องที่รันจากโฟลเดอร์ repo (เครื่องพัฒนา) ห้ามอัปเดตทับไฟล์ที่กำลังแก้อยู่
$DEV = Test-Path (Join-Path (Split-Path $PSScriptRoot) '.git')
function VersionInfo([bool]$check) {
  $r = [ordered]@{ ok = $true; version = $state.ver; os = $OS; ps = $PSVersionTable.PSVersion.ToString(); screen = $SCREEN
    installed = (Get-Item $PSCommandPath).LastWriteTime.ToString('yyyy-MM-dd HH:mm'); dev = $DEV }
  if ($check) {
    $rs = RemoteSet $false
    if ($rs.ok) {
      $r.latest = $rs.version
      # เทียบด้วยรายการไฟล์ของชุดใหม่ (เผื่อชุดใหม่มีไฟล์เพิ่ม)
      $r.outdated = (VersionOf (LocalItems $rs.list)) -ne $rs.version
      $ff = Join-Path $PSScriptRoot 'update-failed.txt'
      if ($r.outdated -and (Test-Path $ff) -and ([IO.File]::ReadAllText($ff).Trim() -eq $rs.version)) { $r.failed = $true }
    } else { $r.checkError = $rs.error }
  }
  $r
}
$restartAfter = $null
function DoUpdate {
  if ($DEV) { return @{ ok = $false; error = 'bridge นี้รันจากโฟลเดอร์ repo (เครื่องพัฒนา) — ไม่อัปเดตทับไฟล์ที่กำลังแก้' } }
  $rs = RemoteSet $true
  if (-not $rs.ok) { return @{ ok = $false; error = $rs.error } }
  if ((VersionOf (LocalItems $rs.list)) -eq $rs.version) { return @{ ok = $true; updated = $false; version = $rs.version } }
  Remove-Item (Join-Path $PSScriptRoot 'update-failed.txt') -Force -ErrorAction SilentlyContinue
  # ไฟล์ต้องไม่ว่าง และ .ps1 ต้อง parse ผ่าน — ไฟล์เสีย/โหลดมาไม่ครบจะไม่เขียนทับของเดิม
  foreach ($i in $rs.items) {
    if (-not $i.text) { return @{ ok = $false; error = "ไฟล์ $($i.src) บนเว็บว่างเปล่า" } }
    if ($i.dst -like '*.ps1') {
      $tok = $null; $err = $null
      [void][System.Management.Automation.Language.Parser]::ParseInput($i.text, [ref]$tok, [ref]$err)
      if ($err) { return @{ ok = $false; error = "ไฟล์ $($i.src) บนเว็บมีข้อผิดพลาด: $($err[0].Message)" } }
    }
  }
  $bak = Join-Path $PSScriptRoot 'backup'
  New-Item -ItemType Directory -Force $bak | Out-Null
  $saved = @()
  foreach ($i in $rs.items) {
    $p = Join-Path $PSScriptRoot $i.dst
    if (Test-Path $p) { Copy-Item $p (Join-Path $bak $i.dst) -Force; $saved += $i.dst }
  }
  [IO.File]::WriteAllLines((Join-Path $bak 'files.txt'), [string[]]$saved)
  $utf8 = New-Object System.Text.UTF8Encoding $false; $bom = New-Object System.Text.UTF8Encoding $true
  foreach ($i in $rs.items) {
    $t = if ($OS -eq 'win') { $i.text -replace "`n", "`r`n" } else { $i.text }
    # PowerShell 5.1 อ่าน .ps1 ไม่มี BOM เป็น ANSI (ภาษาไทยเพี้ยน) / .bat มี BOM แล้ว cmd อ่านบรรทัดแรกผิด
    $p = Join-Path $PSScriptRoot $i.dst
    [IO.File]::WriteAllText($p, $t, $(if ($i.dst -like '*.ps1') { $bom } else { $utf8 }))
    if ($OS -ne 'win' -and $i.dst -match '\.(command|sh)$') { & chmod +x $p }
  }
  [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'update.json'), $rs.manifest, $utf8)
  $script:restartAfter = @{ from = $state.ver; to = $rs.version }
  @{ ok = $true; updated = $true; from = $state.ver; version = $rs.version }
}
function StartBridgeProcess {
  if ($OS -eq 'win') {
    # เหมือน start-bridge.bat: conhost = คอนโซลแบบเดิม (Windows Terminal ไม่ยอมซ่อนหน้าต่าง)
    Start-Process conhost.exe -ArgumentList "powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$PSCommandPath`"" -WindowStyle Minimized
  } else {
    $exe = (Get-Process -Id $PID).Path; $log = Join-Path $PSScriptRoot 'bridge.log'
    & /bin/bash -c "nohup '$exe' -NoProfile -File '$PSCommandPath' >> '$log' 2>&1 &"
  }
}
# เฉพาะตัวที่รันไฟล์เดียวกับตัวนี้ (ไม่ไปปิด bridge ตัวอื่นในเครื่อง เช่นตัวทดสอบพอร์ตอื่น)
function OtherBridges {
  if ($OS -eq 'win') {
    @(Get-CimInstance Win32_Process -Filter "Name='powershell.exe'" | Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -and $_.CommandLine.Contains($PSCommandPath) } | ForEach-Object { [int]$_.ProcessId })
  } else { @(& pgrep -f -- ([regex]::Escape($PSCommandPath)) | ForEach-Object { [int]$_ } | Where-Object { $_ -ne $PID }) }
}
# Windows ต่อพอร์ตที่ไม่มีใครเปิดใช้เวลา ~2 วินาทีกว่าจะรู้ว่าไม่ได้ จึงรอแค่ 500 ms ต่อครั้ง
function BridgeUp {
  $c = New-Object System.Net.Sockets.TcpClient
  try { $ok = $c.ConnectAsync('127.0.0.1', $PORT).Wait(500) -and $c.Connected } catch { $ok = $false }
  $c.Close(); $ok
}
# ปิดพอร์ตแล้วเปิดตัวใหม่ รอดูว่าตัวใหม่เปิดพอร์ตได้ภายใน 40 วินาที — ไม่ได้ (เปิดไม่ขึ้น) ให้คืนไฟล์จาก backup\ แล้วเปิดตัวเดิมกลับมา
function RestartAfterUpdate {
  Write-Host "อัปเดต bridge $($restartAfter.from) → $($restartAfter.to) เปิดตัวใหม่ $(Get-Date -Format 'HH:mm:ss')"
  $listener.Stop()
  StartBridgeProcess
  $until = (Get-Date).AddSeconds(40)
  while ((Get-Date) -lt $until) { Start-Sleep -Milliseconds 500; if (BridgeUp) { exit 0 } }
  Write-Host 'ตัวใหม่เปิดไม่ขึ้น — คืนไฟล์เดิมจาก backup'
  foreach ($p in OtherBridges) { try { Stop-Process -Id $p -Force -ErrorAction Stop } catch {} }
  $bak = Join-Path $PSScriptRoot 'backup'
  foreach ($f in [IO.File]::ReadAllLines((Join-Path $bak 'files.txt'))) { if ($f) { Copy-Item (Join-Path $bak $f) (Join-Path $PSScriptRoot $f) -Force } }
  # จำชุดที่เปิดไม่ขึ้นไว้ หน้าเว็บจะไม่สั่งอัปเดตชุดนี้ซ้ำทุกครั้งที่เปิดหน้า (รอชุดใหม่ที่แก้แล้ว)
  [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'update-failed.txt'), $restartAfter.to)
  StartBridgeProcess
  exit 1
}

function Respond($client) {
  $stream = $client.GetStream()
  $stream.ReadTimeout = 1000
  $reader = New-Object System.IO.StreamReader($stream, [System.Text.Encoding]::ASCII)
  $first = $reader.ReadLine(); $origin = ''
  while (($line = $reader.ReadLine())) { if ($line -match '^Origin:\s*(.+)$') { $origin = $Matches[1].Trim() } }
  $method = ($first -split ' ')[0]; $path = ($first -split ' ')[1]
  $cors = ''
  if ($ALLOWED_ORIGINS -contains $origin) {
    $cors = "Access-Control-Allow-Origin: $origin`r`nAccess-Control-Allow-Private-Network: true`r`nAccess-Control-Allow-Methods: GET`r`nAccess-Control-Expose-Headers: X-Grid-Hash`r`nVary: Origin`r`n"
  }
  $type = 'application/json; charset=utf-8'; $bytes = [byte[]]@()
  if ($method -eq 'OPTIONS') { $status = '204 No Content' }
  elseif ($path -like '/version*') { $status = '200 OK'; $bytes = [System.Text.Encoding]::UTF8.GetBytes(((VersionInfo ($path -match '[?&]check=1')) | ConvertTo-Json -Compress)) }
  elseif ($path -like '/update*') {
    $status = '200 OK'
    $res = if ($UPDATE_ORIGINS -notcontains $origin) { @{ ok = $false; error = 'สั่งอัปเดตได้จากหน้าเว็บของ รพ. เท่านั้น' } } else { try { DoUpdate } catch { @{ ok = $false; error = "$_" } } }
    $bytes = [System.Text.Encoding]::UTF8.GetBytes(($res | ConvertTo-Json -Compress))
  }
  elseif ($path -like '/current*') { $status = '200 OK'; $bytes = [System.Text.Encoding]::UTF8.GetBytes(($state | ConvertTo-Json -Compress)) }
  elseif ($path -like '/db/*') { $status = '200 OK'; $bytes = [System.Text.Encoding]::UTF8.GetBytes((DbEndpoint $path)) }
  elseif ($path -like '/grid.png*' -and $script:gridPng) { $status = '200 OK'; $type = 'image/png'; $bytes = $script:gridPng }
  elseif ($path -like '/emrgrid.png*' -and $script:emrGridPng) { $status = '200 OK'; $type = 'image/png'; $bytes = $script:emrGridPng }
  else { $status = '404 Not Found' }
  $extra = if ($path -like '/grid.png*' -and $state.gridHash) { "X-Grid-Hash: $($state.gridHash)`r`n" }
    elseif ($path -like '/emrgrid.png*' -and $state.emrGridHash) { "X-Grid-Hash: $($state.emrGridHash)`r`n" } else { '' }
  $head = "HTTP/1.1 $status`r`nContent-Type: $type`r`nCache-Control: no-store`r`n$cors$extra" + "Content-Length: $($bytes.Length)`r`nConnection: close`r`n`r`n"
  $hb = [System.Text.Encoding]::ASCII.GetBytes($head)
  $stream.Write($hb, 0, $hb.Length)
  if ($bytes.Length) { $stream.Write($bytes, 0, $bytes.Length) }
  $client.Close()
}

$state.ver = VersionOf (LocalItems (LocalList))
$listener = New-Object System.Net.Sockets.TcpListener([System.Net.IPAddress]::Loopback, $PORT)
try { $listener.Start() } catch { Write-Host "เปิดพอร์ต $PORT ไม่ได้ — อาจมี HOSxP Bridge เปิดอยู่แล้ว"; exit 1 }
Write-Host "HOSxP Bridge $($state.ver) ($OS) ทำงานแล้ว ที่ http://127.0.0.1:$PORT/current  (หยุด: stop-bridge.bat)"
if ($db) { try { [void](DbQuery 'SELECT 1'); Write-Host "เชื่อมฐานข้อมูล HOSxP แล้ว" } catch { Write-Host "ยังเชื่อมฐานข้อมูลไม่ได้: $_ (ใช้ OCR แทน)" } }
else { Write-Host "ไม่ได้ตั้งฐานข้อมูล ($($state.dbErr)) — ใช้ OCR" }
# อ่านหน้าจอ / ปุ่มลัด / หน้าต่างพิมพ์สรุปยากลับบ้าน ใช้ได้เฉพาะ Windows
if ($SCREEN) {
# เครื่องพิมพ์สรุปยากลับบ้าน — bridge เปิดหน้าต่างพิมพ์อัตโนมัติให้เอง (ย่อไว้) และเปิดใหม่ถ้าถูกปิด เปิดแค่ bridge ตัวเดียวก็พิมพ์ได้
$hmeProf = Join-Path $env:LOCALAPPDATA 'TPH-AutoPrint'
$hmeBat = Join-Path $PSScriptRoot 'HME-AutoPrint.bat'
function HmeWatch {
  if (-not (HmeStation) -or -not (Test-Path $hmeBat)) { return }
  $up = Get-CimInstance Win32_Process -Filter "Name='chrome.exe' OR Name='msedge.exe'" | Where-Object { $_.CommandLine -like "*$hmeProf*" } | Select-Object -First 1
  if ($up) { return }
  Write-Host "เปิดหน้าต่างพิมพ์สรุปยากลับบ้านอัตโนมัติ $(Get-Date -Format 'HH:mm')"
  Start-Process cmd.exe -ArgumentList '/c', "`"$hmeBat`" bridge" -WindowStyle Hidden
}
# ── ปุ่มลัดเปิดหน้าต่างลอย ─────────────────────────
$CLINIC_URL = 'https://oatsudster.github.io/pharmacy-tph/clinic.html'
$CLINIC_TITLE = 'งานเภสัชกรรมคลินิก'                                    # <title> ของ clinic.html
$FLOAT_TITLES = @{ rph = 'จ่ายยา (เภสัชกร)'; tech = 'ยาคงเหลือ (จพ.)' }   # <title> ของหน้าต่างลอยแต่ละแบบ
$HOTKEYS = @{ 1 = 'rph'; 2 = 'tech' }
# 0x4003 = Ctrl+Alt (+ ไม่ยิงซ้ำตอนกดค้าง), 0x50 = P, 0x4A = J
# ลงไม่ได้ให้ลองใหม่ในลูปหลักทุก 5 วินาที — ตอนอัปเดตตัวเอง ตัวเก่ายังถือปุ่มลัดอยู่จนกว่าตัวใหม่จะเปิดพอร์ตได้แล้วตัวเก่าจึงปิด
$hkPending = @(@(1, 0x50, 'Ctrl+Alt+P'), @(2, 0x4A, 'Ctrl+Alt+J'))
function RegisterHotkeys([bool]$report) {
  $script:hkPending = @($script:hkPending | Where-Object {
    $ok = [HxWin]::RegisterHotKey([IntPtr]::Zero, $_[0], 0x4003, $_[1])
    if (-not $ok -and $report) { Write-Host "ลงทะเบียนปุ่มลัด $($_[2]) ไม่ได้ (โปรแกรมอื่นใช้อยู่) — จะลองใหม่เรื่อยๆ" }
    -not $ok })
}
RegisterHotkeys $true
$nextHk = (Get-Date).AddSeconds(5)
$tabCond = New-Object System.Windows.Automation.PropertyCondition($AE::ControlTypeProperty, [System.Windows.Automation.ControlType]::TabItem)
function OnHotkey($mode) {
  $state.hotkey = $mode; $state.hotkeySeq++; $state.hotkeyTs = [DateTimeOffset]::Now.ToUnixTimeMilliseconds()
  # Chrome และ Edge ใช้คลาสหน้าต่างเดียวกัน (รวมถึงหน้าต่างลอย Picture-in-Picture และ popup)
  $wins = @($AE::RootElement.FindAll($TS::Children, (ClassCond 'Chrome_WidgetWin_1')))
  foreach ($w in $wins) {
    if ($w.Current.Name -like "*$($FLOAT_TITLES[$mode])*") { [HxWin]::Focus([IntPtr]$w.Current.NativeWindowHandle); return }
  }
  # แท็บที่เปิดอยู่ = ชื่อหน้าต่าง, แท็บอื่นหาจากแถบแท็บ (UI Automation) แล้วสลับไป
  foreach ($w in $wins) { if ($w.Current.Name -like "$CLINIC_TITLE*") { [HxWin]::Focus([IntPtr]$w.Current.NativeWindowHandle); return } }
  foreach ($w in $wins) {
    foreach ($t in $w.FindAll($TS::Descendants, $tabCond)) {
      if ($t.Current.Name -like "$CLINIC_TITLE*") {
        try { $t.GetCurrentPattern([System.Windows.Automation.SelectionItemPattern]::Pattern).Select() } catch {}
        [HxWin]::Focus([IntPtr]$w.Current.NativeWindowHandle); return
      }
    }
  }
  Start-Process "$CLINIC_URL#float=$mode"
}
}

$nextPoll = [DateTime]::MinValue; $nextHme = (Get-Date).AddSeconds(3)
while ($true) {
  if ($SCREEN) {
    while (($hk = [HxWin]::PollHotkey())) { if ($HOTKEYS.ContainsKey($hk)) { try { OnHotkey $HOTKEYS[$hk] } catch { Write-Host "ปุ่มลัด: $_" } } }
    if ((Get-Date) -ge $nextPoll) { UpdateState; $nextPoll = (Get-Date).AddSeconds(1) }
    if ((Get-Date) -ge $nextHme) { try { HmeWatch } catch {}; $nextHme = (Get-Date).AddSeconds(60) }
    if ($hkPending.Count -and (Get-Date) -ge $nextHk) { RegisterHotkeys $false; $nextHk = (Get-Date).AddSeconds(5) }
  } else {
    if ((Get-Date) -ge $nextMacPoll) { try { MacUpdateState } catch {}; $nextMacPoll = (Get-Date).AddSeconds(2) }
    $state.ts = [DateTimeOffset]::Now.ToUnixTimeMilliseconds()
  }
  while ($listener.Pending()) { try { Respond $listener.AcceptTcpClient() } catch {} }
  if ($restartAfter) { RestartAfterUpdate }
  Start-Sleep -Milliseconds 100
}
